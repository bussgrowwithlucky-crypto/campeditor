"""B-roll pipeline for Replicate mode.

Seven stages, run once per job:
  1. detect_broll_spans   — find every cutaway in the reference timeline (frame
                             clustering + hard-cut splitting on 10fps frames).
  2. describe_spans       — vision-tag each span (subjects/setting/action/
                             category + a short search query), 3 sampled frames.
  3. build_library_index  — scan the local B-roll library once, vision-tag each
                             clip, cache the result forever (incremental).
  4. match_local           — cheap category/subject/setting scoring over the
                             index, LLM tie-break over the top 5.
  5. search_youtube        — YouTube Data API search (key rotation on
                             403/429), falling back to yt-dlp ytsearch; vision-
                             compare the top 2 candidates' previews, pick the
                             closer one.
  6. crop_reference_cutaway — last resort: a caption-dodging crop of the
                              reference's own cutaway. Always succeeds.
  7. fetch_broll_cuts / fetch_broll_cut_variations / fetch_learned_broll_cuts
                             — place cuts at the reference's exact timestamps.

Every span for a replicate (reference-driven) job produces a cut: Local ->
YouTube -> reference-crop is a guaranteed ladder, so span count always matches
the reference's B-roll cutaway count.
"""

import base64
import hashlib
import json
import logging
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

from app.config import Settings
from app.models import BrollCut, BrollPackItem, BrollRecoveryDiagnostic, ReferenceAnalysis
from app.rendering import probe_duration

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FRAME_FPS = 10.0  # 0.1s timing resolution for reference cut detection
MIN_BROLL_SPAN = 0.08
MIN_OUTPUT_BROLL_SPAN = 0.08
MAX_BROLL_SPANS = 24
SHOT_CUT_DISTANCE = 0.85
PRIMARY_SHOT_DISTANCE = 0.78

VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}
VALID_CATEGORIES = {"movie", "sports", "tech", "lifestyle", "money", "other"}

VISION_TIMEOUT = 25.0
SEARCH_TIMEOUT = 30.0
DOWNLOAD_TIMEOUT = 120.0
PREVIEW_SECONDS = 20.0

YT_MAX_SOURCE_SECONDS = 150
YT_MIN_SOURCE_SECONDS = 3.0
YT_RESULTS_PER_QUERY = 10
# Titles that signal talking-head / commentary uploads rather than clean stock
# footage. Cheap substring reject before any download or vision call.
YT_JUNK_TITLE_TERMS = (
    "podcast", "reaction", "react", "explained", "interview", "tutorial",
    "how to", "review", "vlog", "story time", "storytime", "q&a", "commentary",
    "tier list", "ranking", "compilation of", "top 10", "top ten",
)

_INDEX_CACHE_VERSION = 1


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class SpanProfile:
    """Vision-derived description of one B-roll cutaway."""

    start: float
    end: float
    subjects: list[str] = field(default_factory=list)
    setting: list[str] = field(default_factory=list)
    action: list[str] = field(default_factory=list)
    category: str = "other"
    query: str = ""


@dataclass
class LibraryClip:
    """One local B-roll library file, tagged and cached forever."""

    path: Path
    mtime: float
    size: int
    subjects: list[str]
    setting: list[str]
    category: str
    folder: str
    query: str = ""


# ---------------------------------------------------------------------------
# Vision + LLM ladder
# ---------------------------------------------------------------------------


class _VisionBudget:
    """Optional per-call-sequence time cap. None = uncapped.

    Scoped locally to one caller's loop (e.g. one analyze_reference run) rather
    than shared global state, so a budget spent tagging reference spans can
    never starve an unrelated later stage (library indexing, YouTube preview
    tagging) that happens to run in the same process.
    """

    __slots__ = ("remaining",)

    def __init__(self, seconds: float | None):
        self.remaining = seconds

    def spend(self, seconds: float) -> None:
        if self.remaining is None or seconds <= 0:
            return
        self.remaining = max(0.0, self.remaining - seconds)

    def exhausted(self) -> bool:
        return self.remaining is not None and self.remaining <= 0.0


# Rate-limit cooldown: a provider that just returned 429 (per-minute or daily
# quota) is skipped for this many seconds instead of being retried on every
# call. Without this, an exhausted Groq daily quota turns every vision call
# into a full failed-ladder walk and an analysis stage into a multi-minute
# crawl of guaranteed-failing requests.
_RATE_LIMIT_COOLDOWN_SECONDS = 90.0
_provider_cooldowns: dict[str, float] = {}


def _provider_cooling(provider_key: str) -> bool:
    return time.monotonic() < _provider_cooldowns.get(provider_key, 0.0)


def _cool_provider_if_rate_limited(provider_key: str, error: Exception) -> None:
    if type(error).__name__ == "RateLimitError" or "429" in str(error):
        _provider_cooldowns[provider_key] = time.monotonic() + _RATE_LIMIT_COOLDOWN_SECONDS


def _vision(image_path: Path, prompt: str, settings: Settings, budget: "_VisionBudget | None" = None) -> str:
    """Groq -> NVIDIA (up to 4 keys) -> Gemini -> local Ollama vision ladder.

    `budget` caps only the CLOUD portion of the ladder (Groq/NVIDIA/Gemini):
    once spent, those are skipped outright on every subsequent call so a job
    doesn't re-attempt calls it already knows are failing. Ollama is always
    tried regardless of the cloud budget — it's the offline last resort, and
    gating it on a budget meant to bound flaky *cloud* round-trips would mean
    a job with an exhausted budget silently stops tagging anything at all.
    """
    cloud_budget_available = not (budget is not None and budget.exhausted())
    encoded = base64.b64encode(image_path.read_bytes()).decode()

    def _try_vision(api_key: str, base_url: str, model: str, timeout: float = VISION_TIMEOUT, **extra) -> str:
        from openai import OpenAI

        client = OpenAI(api_key=api_key, base_url=base_url, timeout=timeout, max_retries=0)
        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{encoded}"}},
                    ],
                }
            ],
            temperature=0.2,
            max_tokens=150,
            **extra,
        )
        choice = response.choices[0] if response.choices else None
        return ((choice.message.content if choice and choice.message else None) or "").strip()

    if cloud_budget_available and settings.groq_api_key and not _provider_cooling("groq"):
        started_at = time.monotonic()
        try:
            result = _try_vision(settings.groq_api_key, "https://api.groq.com/openai/v1", settings.groq_vision_model)
            if budget is not None:
                budget.spend(time.monotonic() - started_at)
            if result:
                return result
        except Exception as e:
            logger.warning("Groq vision failed (%s): %s", type(e).__name__, e)
            _cool_provider_if_rate_limited("groq", e)
            if budget is not None:
                budget.spend(time.monotonic() - started_at)
                cloud_budget_available = not budget.exhausted()

    nvidia_keys = [
        k for k in (
            settings.nvidia_api_key,
            settings.nvidia_fallback_api_key,
            settings.nvidia_fallback_api_key_2,
            settings.nvidia_fallback_api_key_3,
        ) if k
    ]
    for index, nvidia_key in enumerate(nvidia_keys):
        if not cloud_budget_available or _provider_cooling(f"nvidia{index}"):
            continue
        started_at = time.monotonic()
        try:
            result = _try_vision(nvidia_key, settings.nvidia_base_url, settings.nvidia_vision_model)
            if budget is not None:
                budget.spend(time.monotonic() - started_at)
                cloud_budget_available = not budget.exhausted()
            if result:
                return result
        except Exception as e:
            logger.warning("NVIDIA vision key #%d failed (%s): %s", index, type(e).__name__, e)
            _cool_provider_if_rate_limited(f"nvidia{index}", e)
            if budget is not None:
                budget.spend(time.monotonic() - started_at)
                cloud_budget_available = not budget.exhausted()

    if cloud_budget_available and settings.gemini_api_key and not _provider_cooling("gemini"):
        started_at = time.monotonic()
        try:
            result = _try_vision(
                settings.gemini_api_key, settings.gemini_base_url, settings.gemini_vision_model,
                reasoning_effort="none",
            )
            if budget is not None:
                budget.spend(time.monotonic() - started_at)
            if result:
                return result
        except Exception as e:
            logger.warning("Gemini vision failed (%s): %s", type(e).__name__, e)
            _cool_provider_if_rate_limited("gemini", e)
            if budget is not None:
                budget.spend(time.monotonic() - started_at)

    # Local Ollama model — the offline last resort when every cloud provider
    # is down or rate-limited. Slower (CPU inference) but never quota-bound.
    # Always attempted regardless of the cloud budget above (see docstring).
    if settings.ollama_vision_model and not _provider_cooling("ollama"):
        try:
            result = _try_vision(
                "ollama", settings.ollama_base_url, settings.ollama_vision_model,
                timeout=120.0,
            )
            if result:
                return result
        except Exception as e:
            logger.warning("Ollama local vision failed (%s): %s", type(e).__name__, e)
            # Connection refused = Ollama not running; don't hammer it.
            _provider_cooldowns["ollama"] = time.monotonic() + _RATE_LIMIT_COOLDOWN_SECONDS
    return ""


def _chat(prompt: str, settings: Settings, timeout: float = 15.0) -> str:
    """Single-shot chat completion against the configured LLM ladder. Used for
    the local-library tie-break and (indirectly) nothing else — kept tiny and
    single-purpose. Returns "" on failure."""
    from openai import OpenAI

    from app.title_generation import provider_ladder, _cool_chat_provider_on_billing_or_rate_limit, _provider_key_for

    for base_url, api_key, model in provider_ladder(settings):
        provider_key = _provider_key_for(base_url, model, settings)
        try:
            client = OpenAI(api_key=api_key, base_url=base_url, timeout=timeout, max_retries=0)
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=100,
            )
            choice = response.choices[0] if response.choices else None
            text = (choice.message.content if choice and choice.message else None) or ""
            if text.strip():
                return text
        except Exception as exc:
            _cool_chat_provider_on_billing_or_rate_limit(provider_key, exc)
            logger.exception("B-roll LLM chat (%s) failed", model)
    return ""


# ---------------------------------------------------------------------------
# Stage 1: cutaway detection
# ---------------------------------------------------------------------------


def extract_reference_frames(source: Path, duration: float, frames_dir: Path, settings: Settings) -> list[Path]:
    frames_dir.mkdir(parents=True, exist_ok=True)
    for old_frame in frames_dir.glob("frame-*.jpg"):
        old_frame.unlink(missing_ok=True)
    result = subprocess.run(
        [
            settings.ffmpeg_path,
            "-y",
            "-i", str(source),
            "-t", f"{duration:.3f}",
            "-vf", f"fps={FRAME_FPS},scale=400:-1",
            str(frames_dir / "frame-%04d.jpg"),
        ],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if result.returncode != 0:
        logger.warning("Reference frame extraction failed: %s", result.stderr[-300:])
        return []
    return sorted(frames_dir.glob("frame-*.jpg"))


def _reference_frame_feature(frame_path: Path, cv2, np):
    frame = cv2.imread(str(frame_path))
    if frame is None:
        return None
    height = frame.shape[0]
    crop = frame[int(height * 0.18):int(height * 0.82), :]
    if crop.size == 0:
        crop = frame
    small = cv2.resize(crop, (32, 32)).astype("float32") / 255.0
    hsv = cv2.cvtColor(cv2.resize(crop, (96, 96)), cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], None, [8, 4], [0, 180, 0, 256]).flatten().astype("float32")
    hist = hist / (hist.sum() or 1)
    feat = np.concatenate([small.flatten() * 0.55, hist * 2.0])
    feat = feat - feat.mean()
    norm = np.linalg.norm(feat)
    return feat / (norm or 1)


def _primary_shot_centroid(features, np):
    clusters: list[dict] = []
    for index, feature in enumerate(features):
        best: tuple[float, dict] | None = None
        for cluster in clusters:
            distance = float(np.linalg.norm(feature - cluster["centroid"]))
            if best is None or distance < best[0]:
                best = (distance, cluster)
        if best and best[0] < PRIMARY_SHOT_DISTANCE:
            cluster = best[1]
            cluster["indices"].append(index)
            centroid = features[cluster["indices"]].mean(axis=0)
            cluster["centroid"] = centroid / (np.linalg.norm(centroid) or 1)
        else:
            clusters.append({"indices": [index], "centroid": feature.copy()})
    if not clusters:
        return None
    primary = max(clusters, key=lambda c: len(c["indices"]))
    return primary["centroid"]


def _shot_cut_indices(features, np) -> list[int]:
    cuts: list[int] = []
    for index in range(1, len(features)):
        if float(np.linalg.norm(features[index] - features[index - 1])) >= SHOT_CUT_DISTANCE:
            cuts.append(index)
    return cuts


def _has_cutaway_visual_energy(frame_path: Path) -> bool:
    try:
        import cv2
    except ImportError:
        return True
    frame = cv2.imread(str(frame_path))
    if frame is None:
        return False
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    height = gray.shape[0]
    band = gray[int(height * 0.18):int(height * 0.82), :]
    if band.size == 0:
        band = gray
    lit_ratio = float((band > 24).mean())
    mean = float(band.mean())
    contrast = float(band.std())
    edges = cv2.Canny(band, 80, 180)
    edge_density = float(edges.mean() / 255)
    bright_image = lit_ratio > 0.28 and mean > 20 and (contrast > 12 or edge_density > 0.01)
    dark_textured_image = lit_ratio > 0.10 and contrast > 14 and edge_density > 0.018
    return bright_image or dark_textured_image


def _spans_from_shot_flags(
    primary_flags: list[bool],
    visual_flags: list[bool],
    cut_indices: list[int],
) -> list[tuple[float, float]]:
    boundaries = [0]
    boundaries.extend(i for i in sorted(set(cut_indices)) if 0 < i < len(primary_flags))
    boundaries.append(len(primary_flags))

    spans: list[tuple[float, float]] = []
    for start_index, end_index in zip(boundaries, boundaries[1:]):
        length = end_index - start_index
        if length <= 0:
            continue
        primary_ratio = sum(primary_flags[start_index:end_index]) / length
        visual_ratio = sum(visual_flags[start_index:end_index]) / length
        if primary_ratio <= 0.45 and visual_ratio >= 0.5:
            start_t = start_index / FRAME_FPS
            end_t = end_index / FRAME_FPS
            if end_t - start_t >= MIN_BROLL_SPAN:
                spans.append((start_t, end_t))
    return spans[:MAX_BROLL_SPANS]


def _shot_based_spans(frames: list[Path]) -> list[tuple[float, float]]:
    """Learn the recurring talking-head shot and treat visually different
    shots as B-roll, split on hard cuts so each cutaway keeps its own timing."""
    if len(frames) < 2:
        return []
    try:
        import cv2
        import numpy as np
    except ImportError:
        return []

    features = [_reference_frame_feature(frame, cv2, np) for frame in frames]
    if any(f is None for f in features):
        return []
    feature_array = np.array(features, dtype="float32")
    primary_centroid = _primary_shot_centroid(feature_array, np)
    if primary_centroid is None:
        return []

    primary_flags = [
        float(np.linalg.norm(feature - primary_centroid)) <= PRIMARY_SHOT_DISTANCE
        for feature in feature_array
    ]
    visual_flags = [_has_cutaway_visual_energy(frame) for frame in frames]
    cut_indices = _shot_cut_indices(feature_array, np)
    return _spans_from_shot_flags(primary_flags, visual_flags, cut_indices)


def _face_flags(frames: list[Path]) -> list[bool]:
    try:
        import cv2
    except ImportError:
        return [True] * len(frames)
    cascade = cv2.CascadeClassifier(str(Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml"))
    if cascade.empty():
        return [True] * len(frames)
    flags: list[bool] = []
    for frame_path in frames:
        frame = cv2.imread(str(frame_path))
        if frame is None:
            flags.append(True)
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=(32, 32))
        flags.append(len(faces) > 0)
    return flags


def _fill_single_frame_gaps(flags: list[bool]) -> list[bool]:
    if len(flags) < 3:
        return flags
    smoothed = list(flags)
    for index in range(1, len(flags) - 1):
        if not flags[index] and flags[index - 1] and flags[index + 1]:
            smoothed[index] = True
    return smoothed


def _spans_from_flags(flags: list[bool]) -> list[tuple[float, float]]:
    """Maximal runs of consecutive True frames, as (start, end) seconds."""
    flags = _fill_single_frame_gaps(flags)
    spans: list[tuple[float, float]] = []
    run_start: int | None = None
    for index, is_broll in enumerate(flags + [False]):
        if is_broll and run_start is None:
            run_start = index
        elif not is_broll and run_start is not None:
            start_t = run_start / FRAME_FPS
            end_t = index / FRAME_FPS
            if end_t - start_t >= MIN_BROLL_SPAN:
                spans.append((start_t, end_t))
            run_start = None
    return spans[:MAX_BROLL_SPANS]


def detect_broll_spans(frames: list[Path]) -> list[tuple[float, float]]:
    """Detect every B-roll cutaway in the reference timeline. Primary method
    is shot clustering (works even when B-roll contains faces); falls back to
    a no-face-frames heuristic when OpenCV/features are unavailable."""
    spans = _shot_based_spans(frames)
    if spans:
        return spans
    face_flags = _face_flags(frames)
    return _spans_from_flags([not has_face for has_face in face_flags])


# ---------------------------------------------------------------------------
# Stage 2: span description (vision tagging)
# ---------------------------------------------------------------------------

_TAG_PROMPT = (
    "You are analyzing a single video frame for a B-roll matching system. "
    "Reply with ONLY a JSON object (no markdown, no prose) with these exact keys:\n"
    '{"subjects": list of 1-3 concrete nouns (objects/people, lowercase), '
    '"setting": list of 1-2 location descriptors (e.g. ["office","indoors"]), '
    '"action": list of 0-2 verbs (e.g. ["typing","running"]), '
    '"category": one of [movie, sports, tech, lifestyle, money, other], '
    '"query": a short stock-footage search phrase of 3-8 words describing the shot}.\n'
    "Ignore any burned-in text/captions. Use empty lists when nothing fits."
)


def _frame_content_hash(frame_path: Path) -> str:
    h = hashlib.sha256()
    try:
        with frame_path.open("rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
    except Exception:
        try:
            stat = frame_path.stat()
            h.update(f"{frame_path}:{stat.st_size}:{int(stat.st_mtime)}".encode())
        except Exception:
            h.update(str(frame_path).encode())
    return h.hexdigest()


def _tags_cache_dir(settings: Settings) -> Path:
    return settings.data_dir / "cache" / "broll_tags"


def _parse_tags(raw: str) -> dict:
    if not raw:
        return {}
    text = raw.strip()
    if text.startswith("```"):
        text = text.lstrip("`")
        if "\n" in text:
            _, _, rest = text.partition("\n")
            text = rest
        if text.endswith("```"):
            text = text[:-3]
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return {}
    try:
        obj = json.loads(text[start:end + 1])
    except Exception:
        return {}
    if not isinstance(obj, dict):
        return {}

    def _as_list(v, cap: int) -> list[str]:
        if isinstance(v, list):
            return [str(x).strip().lower() for x in v if str(x).strip()][:cap]
        if isinstance(v, str) and v.strip():
            return [v.strip().lower()]
        return []

    category = str(obj.get("category", "")).strip().lower()
    if category not in VALID_CATEGORIES:
        category = ""
    query = " ".join(str(obj.get("query", "")).split())

    return {
        "subjects": _as_list(obj.get("subjects"), 3),
        "setting": _as_list(obj.get("setting"), 2),
        "action": _as_list(obj.get("action"), 2),
        "category": category,
        "query": query,
    }


def _frame_tags(frame_path: Path | None, settings: Settings, budget: "_VisionBudget | None") -> dict:
    """Structured scene tags for a single frame, disk-cached by frame hash so
    re-tagging across jobs/variations/library rebuilds is free."""
    if frame_path is None or not frame_path.exists():
        return {}
    cache_dir = _tags_cache_dir(settings)
    frame_hash = _frame_content_hash(frame_path)
    cache_file = cache_dir / f"{frame_hash}.json"
    try:
        if cache_file.exists():
            return json.loads(cache_file.read_text(encoding="utf-8"))
    except Exception:
        pass
    try:
        raw = _vision(frame_path, _TAG_PROMPT, settings, budget)
    except Exception:
        logger.exception("B-roll frame-tag vision failed for %s", frame_path)
        return {}
    tags = _parse_tags(raw)
    if tags:
        try:
            cache_dir.mkdir(parents=True, exist_ok=True)
            cache_file.write_text(json.dumps(tags, ensure_ascii=False), encoding="utf-8")
        except Exception:
            logger.debug("broll tag cache write failed for %s", frame_hash)
    return tags


def _merge_tags(frame_tag_list: list[dict]) -> dict:
    """Union a list of per-frame tag dicts into one span/clip-level dict."""
    if not frame_tag_list:
        return {}

    def _union(key: str, cap: int) -> list[str]:
        seen: list[str] = []
        for tags in frame_tag_list:
            for v in tags.get(key, []):
                if v and v not in seen:
                    seen.append(v)
                if len(seen) >= cap:
                    return seen
        return seen

    counts: dict[str, int] = {}
    for tags in frame_tag_list:
        c = tags.get("category", "")
        if c:
            counts[c] = counts.get(c, 0) + 1
    category = max(counts, key=lambda k: counts[k]) if counts else ""

    # Prefer the middle sample's query (most representative of the span);
    # fall back to the first non-empty one found.
    query = ""
    mid = len(frame_tag_list) // 2
    order = [mid] + [i for i in range(len(frame_tag_list)) if i != mid]
    for i in order:
        q = frame_tag_list[i].get("query", "")
        if q:
            query = q
            break

    return {
        "subjects": _union("subjects", 4),
        "setting": _union("setting", 2),
        "action": _union("action", 2),
        "category": category,
        "query": query,
    }


def _sample_span_frames(start: float, end: float, frames: list[Path]) -> list[Path]:
    """Sample up to 3 frames at 25/50/75% of the span's frame range."""
    if not frames:
        return []
    lo = max(0, min(len(frames) - 1, int(start * FRAME_FPS)))
    hi = max(lo, min(len(frames) - 1, int(end * FRAME_FPS)))
    span_frames = frames[lo:hi + 1] or [frames[lo]]
    if len(span_frames) <= 3:
        return span_frames
    return [span_frames[min(len(span_frames) - 1, int(frac * len(span_frames)))] for frac in (0.25, 0.5, 0.75)]


def _truncate_query(query: str, settings: Settings) -> str:
    words = (query or "").split()
    limit = max(1, settings.broll_query_max_words)
    return " ".join(words[:limit])


def describe_spans(spans: list[tuple[float, float]], frames: list[Path], settings: Settings) -> list[SpanProfile]:
    """Vision-tag every detected span. Budget scoped to this call only, sized
    by span count, so a job with many spans can't hang forever on flaky keys."""
    budget = _VisionBudget(min(480.0, max(120.0, 40.0 * max(1, len(spans)))))
    profiles: list[SpanProfile] = []
    for start, end in spans:
        sample_frames = _sample_span_frames(start, end, frames)
        frame_tags = [_frame_tags(f, settings, budget) for f in sample_frames]
        merged = _merge_tags(frame_tags)
        profiles.append(SpanProfile(
            start=start,
            end=end,
            subjects=merged.get("subjects", []),
            setting=merged.get("setting", []),
            action=merged.get("action", []),
            category=merged.get("category") or "other",
            query=_truncate_query(merged.get("query", ""), settings),
        ))
    return profiles


# ---------------------------------------------------------------------------
# Stage 3: local library index
# ---------------------------------------------------------------------------


def _folder_category(folder: str) -> str:
    """Seed a default category from the library's folder-name conventions."""
    key = folder.strip().lower().replace("_", " ")
    if "good stuff" in key:
        return "movie"
    if "nba" in key:
        return "sports"
    if "ronaldo" in key:
        return "sports"
    return "other"


def _extract_single_frame(source: Path, at_seconds: float, output_path: Path, settings: Settings) -> bool:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = subprocess.run(
            [
                settings.ffmpeg_path,
                "-y",
                "-ss", f"{max(0.0, at_seconds):.3f}",
                "-i", str(source),
                "-frames:v", "1",
                "-vf", "scale=320:-1",
                str(output_path),
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        return False
    return result.returncode == 0 and output_path.exists() and output_path.stat().st_size > 500


def _tag_library_clip(path: Path, settings: Settings, budget: "_VisionBudget | None") -> dict:
    try:
        duration = probe_duration(path, settings)
    except Exception:
        duration = 0.0
    if duration <= 0:
        return {}
    sample_dir = settings.data_dir / "cache" / "broll_library_frames"
    key = hashlib.md5(str(path.resolve()).encode()).hexdigest()[:16]
    frame_tags: list[dict] = []
    for frac in (0.33, 0.66):
        at = max(0.0, min(duration - 0.05, duration * frac))
        frame_path = sample_dir / f"{key}_{int(frac * 100)}.jpg"
        if not frame_path.exists():
            _extract_single_frame(path, at, frame_path, settings)
        if frame_path.exists():
            frame_tags.append(_frame_tags(frame_path, settings, budget))
    return _merge_tags(frame_tags)


def _index_cache_path(settings: Settings) -> Path:
    return settings.data_dir / "cache" / "broll_index.json"


def build_library_index(settings: Settings) -> list[LibraryClip]:
    """Scan the local B-roll library once, tag every new/changed file with
    vision, and cache the result forever at data/cache/broll_index.json.
    Incremental: unchanged files (same mtime+size) are read straight from
    cache, so only new library additions pay the vision cost."""
    library_dir = settings.broll_library_dir
    if not library_dir.exists():
        return []
    cache_path = _index_cache_path(settings)
    cached: dict[str, dict] = {}
    if cache_path.exists():
        try:
            raw = json.loads(cache_path.read_text(encoding="utf-8"))
            if raw.get("version") == _INDEX_CACHE_VERSION:
                cached = raw.get("clips", {})
        except Exception:
            cached = {}

    files = sorted(p for p in library_dir.rglob("*") if p.is_file() and p.suffix.lower() in VIDEO_EXTS)
    clips: list[LibraryClip] = []
    changed = False
    budget = _VisionBudget(None)  # uncapped: one-time build, deterministic call count, disk-cached forever
    # When every vision provider is down (rate-limited / quota-exhausted),
    # tagging 290 clips would waste ~2 failed ladder walks per clip. After a
    # few consecutive all-frames-failed clips, stop calling vision for the
    # rest of this run: those clips get folder-seeded categories NOW but are
    # NOT persisted, so the next run (with providers back) tags them properly.
    consecutive_vision_failures = 0
    vision_disabled = False

    for path in files:
        try:
            stat = path.stat()
        except OSError:
            continue
        key = str(path.resolve())
        entry = cached.get(key)
        if entry and entry.get("mtime") == stat.st_mtime and entry.get("size") == stat.st_size:
            clips.append(LibraryClip(
                path=path, mtime=stat.st_mtime, size=stat.st_size,
                subjects=entry.get("subjects", []), setting=entry.get("setting", []),
                category=entry.get("category", "other"), folder=entry.get("folder", ""),
                query=entry.get("query", ""),
            ))
            continue

        folder = path.parent.name
        tagged = {} if vision_disabled else _tag_library_clip(path, settings, budget)
        if not vision_disabled:
            if tagged.get("subjects") or tagged.get("query"):
                consecutive_vision_failures = 0
            else:
                consecutive_vision_failures += 1
                if consecutive_vision_failures >= 4:
                    vision_disabled = True
                    logger.warning(
                        "B-roll library tagging: vision failing repeatedly; "
                        "using folder categories for remaining untagged clips this run"
                    )
        category = tagged.get("category") or _folder_category(folder)
        clip = LibraryClip(
            path=path, mtime=stat.st_mtime, size=stat.st_size,
            subjects=tagged.get("subjects", []), setting=tagged.get("setting", []),
            category=category, folder=folder, query=tagged.get("query", ""),
        )
        clips.append(clip)
        # Persist only successfully-tagged entries: an empty-tag entry written
        # to the cache would never be retried once providers recover.
        if tagged.get("subjects") or tagged.get("query"):
            cached[key] = {
                "mtime": stat.st_mtime, "size": stat.st_size,
                "subjects": clip.subjects, "setting": clip.setting,
                "category": clip.category, "folder": clip.folder, "query": clip.query,
            }
            changed = True

    if changed:
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = cache_path.with_suffix(".tmp")
            tmp.write_text(
                json.dumps({"version": _INDEX_CACHE_VERSION, "clips": cached}, ensure_ascii=False),
                encoding="utf-8",
            )
            tmp.replace(cache_path)
        except Exception:
            logger.exception("Failed to persist B-roll library index cache")
    return clips


# ---------------------------------------------------------------------------
# Stage 4: local matching
# ---------------------------------------------------------------------------


_LOCAL_SCORE_MAX = 8.0  # 3.0 (category) + 3.0 (subjects, cap 3) + 2.0 (setting, cap 2)


def _local_score(profile: SpanProfile, clip: LibraryClip) -> float:
    """0..1 normalized match score: category match is the strong signal,
    subject/setting overlap add smaller weights on top."""
    score = 0.0
    if profile.category and clip.category and profile.category == clip.category:
        score += 3.0
    score += len(set(profile.subjects) & set(clip.subjects)) * 1.0
    score += len(set(profile.setting) & set(clip.setting)) * 1.0
    return min(1.0, score / _LOCAL_SCORE_MAX)


def _rank_local(profile: SpanProfile, index: list[LibraryClip], used_clips: set[Path]) -> list[tuple[LibraryClip, float]]:
    scored: list[tuple[LibraryClip, float]] = []
    for clip in index:
        try:
            if clip.path.resolve() in used_clips:
                continue
        except OSError:
            continue
        scored.append((clip, _local_score(profile, clip)))
    scored.sort(key=lambda t: t[1], reverse=True)
    return scored


def _profile_description(profile: SpanProfile) -> str:
    parts = list(profile.subjects) + list(profile.setting)
    if profile.action:
        parts.append(", ".join(profile.action))
    text = ", ".join(p for p in parts if p) or profile.query or profile.category
    return f"{text} (category: {profile.category})"


def _llm_pick_local(profile: SpanProfile, ranked_top: list[tuple[LibraryClip, float]], settings: Settings) -> LibraryClip | None:
    if not ranked_top:
        return None
    lines = []
    for i, (clip, _score) in enumerate(ranked_top):
        desc = ", ".join(clip.subjects + clip.setting) or clip.category
        lines.append(f"{i}: {clip.category} — {desc} (folder: {clip.folder})")
    prompt = (
        f"Reference cutaway shows: {_profile_description(profile)}.\n"
        "Which of these candidate library clips shows the same kind of "
        "objects/scene/location category? Same category in a different exact "
        "place is fine (e.g. laptop-at-home matches PC-at-home). Reply with "
        "ONLY the number, or NONE if none are a reasonable match.\n" + "\n".join(lines)
    )
    try:
        raw = _chat(prompt, settings, timeout=15.0)
    except Exception:
        return None
    if not raw or "none" in raw.strip().lower()[:12]:
        return None
    match = re.search(r"\d+", raw)
    if not match:
        return None
    idx = int(match.group())
    if 0 <= idx < len(ranked_top):
        return ranked_top[idx][0]
    return None


def match_local(profile: SpanProfile, index: list[LibraryClip], used_clips: set[Path], settings: Settings) -> LibraryClip | None:
    """Cheap category/subject/setting scoring over the whole index, LLM
    tie-break over the top 5. Falls back to the top score when it clears
    broll_local_match_threshold; None when nothing is close enough (search
    moves on to YouTube)."""
    ranked = _rank_local(profile, index, used_clips)
    if not ranked:
        return None
    top = ranked[:5]
    picked = _llm_pick_local(profile, top, settings)
    if picked is not None:
        return picked
    best_clip, best_score = top[0]
    if best_score >= settings.broll_local_match_threshold:
        return best_clip
    return None


# ---------------------------------------------------------------------------
# Stage 5: YouTube fallback
# ---------------------------------------------------------------------------

_BROWSER_COOKIES_BROKEN = False


def _ytdlp_cookie_args(settings: Settings) -> list[str]:
    global _BROWSER_COOKIES_BROKEN
    cookies_file = settings.ytdlp_cookies_file
    if cookies_file and cookies_file.exists():
        return ["--cookies", str(cookies_file)]
    if settings.ytdlp_cookies_from_browser.strip() and not _BROWSER_COOKIES_BROKEN:
        return ["--cookies-from-browser", settings.ytdlp_cookies_from_browser.strip()]
    return []


def _is_browser_cookie_error(stderr: str) -> bool:
    lowered = stderr.lower()
    if "could not copy" in lowered and "cookie" in lowered:
        return True
    if "failed to decrypt" in lowered and "dpapi" in lowered:
        return True
    if "extract cookies" in lowered and "browser" in lowered:
        return True
    return False


def _iso8601_duration_to_seconds(value: str) -> float:
    """Parse a YouTube contentDetails.duration (ISO-8601, e.g. 'PT1M30S')."""
    if not value:
        return 0.0
    m = re.fullmatch(r"P(?:(\d+)D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", value)
    if not m:
        return 0.0
    days, hours, mins, secs = (int(g) if g else 0 for g in m.groups())
    return days * 86400 + hours * 3600 + mins * 60 + secs


def _is_junk_youtube_entry(url: str, title: str) -> bool:
    if "/shorts/" in url.lower():
        return True
    title_lower = title.lower()
    return any(term in title_lower for term in YT_JUNK_TITLE_TERMS)


def _youtube_data_api_search(query: str, per_query: int, settings: Settings) -> list[dict] | None:
    """Search via the Data API v3. Returns None (not []) when every key
    failed/quota-exceeded, so the caller falls back to yt-dlp ytsearch."""
    keys = settings.youtube_data_api_keys
    if not keys:
        return None
    for key in keys:
        try:
            search_url = "https://www.googleapis.com/youtube/v3/search?" + urllib.parse.urlencode({
                "part": "snippet", "q": query, "type": "video",
                "maxResults": min(50, max(1, per_query)),
                "videoEmbeddable": "true", "key": key,
            })
            with urllib.request.urlopen(search_url, timeout=SEARCH_TIMEOUT) as response:
                data = json.loads(response.read())
        except urllib.error.HTTPError as e:
            if e.code in (403, 429):
                logger.warning("YouTube Data API key rotated (HTTP %s)", e.code)
                continue
            logger.warning("YouTube Data API search failed (HTTP %s)", e.code)
            return None
        except Exception as e:
            logger.warning("YouTube Data API search error (%s): %s", type(e).__name__, e)
            continue

        ids = [item.get("id", {}).get("videoId") for item in data.get("items", []) if item.get("id", {}).get("videoId")]
        if not ids:
            return []
        durations: dict[str, float] = {}
        try:
            videos_url = "https://www.googleapis.com/youtube/v3/videos?" + urllib.parse.urlencode({
                "part": "contentDetails", "id": ",".join(ids), "key": key,
            })
            with urllib.request.urlopen(videos_url, timeout=SEARCH_TIMEOUT) as response:
                vdata = json.loads(response.read())
            for item in vdata.get("items", []):
                durations[item.get("id")] = _iso8601_duration_to_seconds(
                    item.get("contentDetails", {}).get("duration", "")
                )
        except Exception:
            pass
        by_id = {item.get("id", {}).get("videoId"): item.get("snippet", {}) for item in data.get("items", [])}
        entries = []
        for video_id in ids:
            snippet = by_id.get(video_id, {})
            entries.append({
                "id": video_id,
                "url": f"https://www.youtube.com/watch?v={video_id}",
                "duration": durations.get(video_id, 0.0),
                "title": snippet.get("title") or "",
            })
        return entries
    return None


def _yt_dlp_search(query: str, per_query: int, settings: Settings) -> list[dict]:
    command = [
        sys.executable, "-m", "yt_dlp", "--dump-json", "--flat-playlist",
        "--no-download", "--ignore-errors", f"ytsearch{per_query}:{query}",
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=SEARCH_TIMEOUT)
    except subprocess.TimeoutExpired:
        return []
    rows = []
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            info = json.loads(line)
        except json.JSONDecodeError:
            continue
        video_id = info.get("id")
        info["url"] = (
            info.get("url") or info.get("webpage_url") or info.get("original_url")
            or (f"https://www.youtube.com/watch?v={video_id}" if video_id else None)
        )
        rows.append(info)
    return rows


_YT_SEARCH_CACHE_VERSION = 1
# Cache hits older than this are re-fetched: trending videos go stale and a
# 7-day-old hit could be a removed / region-locked clip by now.
_YT_SEARCH_CACHE_TTL_SECONDS = 7 * 24 * 3600


def _yt_search_cache_dir(settings: Settings) -> Path:
    return settings.data_dir / "cache" / "youtube_search"


def _yt_search_cache_key(query: str, settings: Settings) -> Path:
    """Filename hash for a (query, settings) cache entry. Settings fingerprints
    YT_RESULTS_PER_QUERY + the API key set so a quota-rotated key still produces
    a fresh entry."""
    fingerprint = "|".join([
        query.strip().lower(),
        str(YT_RESULTS_PER_QUERY),
        ",".join(settings.youtube_data_api_keys) or "-",
    ])
    digest = hashlib.sha256(fingerprint.encode("utf-8")).hexdigest()[:24]
    return _yt_search_cache_dir(settings) / f"{digest}.json"


def _yt_search_cache_read(query: str, settings: Settings) -> list[dict] | None:
    cache_file = _yt_search_cache_key(query, settings)
    if not cache_file.exists():
        return None
    try:
        payload = json.loads(cache_file.read_text(encoding="utf-8"))
    except Exception:
        return None
    if payload.get("version") != _YT_SEARCH_CACHE_VERSION:
        return None
    cached_at = float(payload.get("cached_at", 0))
    if cached_at <= 0 or (time.time() - cached_at) > _YT_SEARCH_CACHE_TTL_SECONDS:
        return None
    rows = payload.get("rows")
    return rows if isinstance(rows, list) else None


def _yt_search_cache_write(query: str, settings: Settings, rows: list[dict]) -> None:
    try:
        cache_dir = _yt_search_cache_dir(settings)
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = _yt_search_cache_key(query, settings)
        cache_file.write_text(
            json.dumps(
                {"version": _YT_SEARCH_CACHE_VERSION, "cached_at": time.time(), "rows": rows},
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
    except Exception:
        logger.debug("YouTube search cache write failed for query=%s", query)


def _youtube_search_entries(queries: list[str], settings: Settings) -> list[dict]:
    """Aggregate results across query variants, Data API first (falling back
    to yt-dlp ytsearch per query on failure), deduped and junk-filtered.

    Each query is cached on disk for 7 days: re-running the same analysis
    (variations, retries, similar jobs) reuses the search and skips the
    YouTube API quota burn + the yt-dlp round-trip entirely.
    """
    seen_ids: set[str] = set()
    entries: list[dict] = []
    for query in queries:
        api_rows: list[dict] | None
        cached = _yt_search_cache_read(query, settings)
        if cached is not None:
            api_rows = cached
        else:
            fresh = _youtube_data_api_search(query, YT_RESULTS_PER_QUERY, settings)
            api_rows = fresh if fresh is not None else _yt_dlp_search(query, YT_RESULTS_PER_QUERY, settings)
            # Cache even the yt-dlp fallback so the next run skips it.
            if api_rows:
                _yt_search_cache_write(query, settings, api_rows)
        rows = api_rows or []
        for info in rows:
            video_id = info.get("id")
            if not video_id or video_id in seen_ids:
                continue
            duration = float(info.get("duration") or 0)
            if duration and not (YT_MIN_SOURCE_SECONDS <= duration <= YT_MAX_SOURCE_SECONDS):
                continue
            url = info.get("url") or f"https://www.youtube.com/watch?v={video_id}"
            title = info.get("title") or ""
            if _is_junk_youtube_entry(url, title):
                continue
            seen_ids.add(video_id)
            entries.append({"id": video_id, "url": url, "duration": duration, "title": title})
    return entries


def _download_youtube_preview(url: str, output_path: Path, settings: Settings, preview_seconds: float = PREVIEW_SECONDS) -> bool:
    """Short, low-res preview download for vision comparison — not the final
    B-roll source necessarily, but cheap enough to try on every candidate."""
    global _BROWSER_COOKIES_BROKEN
    if output_path.exists() and output_path.stat().st_size > 10_000:
        return True
    output_path.parent.mkdir(parents=True, exist_ok=True)
    base_command = [
        sys.executable, "-m", "yt_dlp", "--no-playlist",
        "-f", "worstvideo[height>=360][ext=mp4]/worst[ext=mp4]/worst",
        "--download-sections", f"*0-{max(3.0, preview_seconds):.0f}",
        "--merge-output-format", "mp4",
        "-o", str(output_path),
    ]
    cookie_args = _ytdlp_cookie_args(settings)
    try:
        result = subprocess.run(base_command + cookie_args + [url], capture_output=True, text=True, timeout=DOWNLOAD_TIMEOUT)
    except subprocess.TimeoutExpired:
        logger.info("YouTube preview download timed out for %s", url)
        output_path.unlink(missing_ok=True)
        return False
    if result.returncode != 0 and cookie_args and "cookie" in result.stderr.lower():
        if _is_browser_cookie_error(result.stderr):
            _BROWSER_COOKIES_BROKEN = True
        try:
            result = subprocess.run(base_command + [url], capture_output=True, text=True, timeout=DOWNLOAD_TIMEOUT)
        except subprocess.TimeoutExpired:
            return False
    return result.returncode == 0 and output_path.exists() and output_path.stat().st_size > 10_000


def _profile_similarity(profile: SpanProfile, tags: dict) -> float:
    score = 0.0
    if profile.category and tags.get("category") and profile.category == tags["category"]:
        score += 3.0
    score += len(set(profile.subjects) & set(tags.get("subjects", []))) * 1.0
    score += len(set(profile.setting) & set(tags.get("setting", []))) * 1.0
    return score


def search_youtube_candidates(
    profile: SpanProfile,
    cache_dir: Path,
    settings: Settings,
    count: int = 2,
) -> list[Path]:
    """Download + score up to `count` YouTube preview candidates for a profile.

    Returns the top-N previews ranked by `_profile_similarity` (subject /
    setting / category overlap against the span's vision tags). Order = best
    first; ties and zero-score candidates are dropped. Empty list when no
    query / no search results / nothing passes the duration check.

    Caller owns the `cache_dir`; this function writes preview_0..N-1.mp4 into
    it and may safely be called from the pack path so multiple spans share a
    single YouTube cache directory without colliding.
    """
    query = _truncate_query(profile.query, settings)
    if not query:
        return []
    cache_dir.mkdir(parents=True, exist_ok=True)
    queries = [query]
    wide = f"{query} b roll"
    if wide.lower() != query.lower():
        queries.append(wide)

    entries = _youtube_search_entries(queries, settings)
    if not entries:
        return []

    scored: list[tuple[Path, float]] = []
    for i, entry in enumerate(entries[: max(count, 2)]):
        preview_path = cache_dir / f"preview_{i}.mp4"
        if not _download_youtube_preview(entry["url"], preview_path, settings):
            continue
        try:
            duration = probe_duration(preview_path, settings)
        except Exception:
            duration = 0.0
        if duration <= 0:
            continue
        frame_path = cache_dir / f"preview_{i}.jpg"
        if not _extract_single_frame(preview_path, duration / 2, frame_path, settings):
            continue
        tags = _frame_tags(frame_path, settings, budget=None)
        score = _profile_similarity(profile, tags)
        if score > 0:
            scored.append((preview_path, score))
    scored.sort(key=lambda pair: pair[1], reverse=True)
    return [path for path, _score in scored[:count]]


def search_youtube(profile: SpanProfile, cache_dir: Path, settings: Settings) -> Path | None:
    """Data-API-first search (key rotation on 403/429) with an automatic
    yt-dlp ytsearch fallback. Thin shim over `search_youtube_candidates` that
    returns the single best preview (or None) — kept so the variation /
    single-clip call sites don't churn."""
    candidates = search_youtube_candidates(profile, cache_dir, settings, count=1)
    return candidates[0] if candidates else None


# ---------------------------------------------------------------------------
# Stage 6: last resort — crop the reference's own cutaway
# ---------------------------------------------------------------------------


def _detect_content_band(reference_path: Path, at_seconds: float, settings: Settings) -> tuple[float, float] | None:
    """(top, height) of the non-black content band, as fractions of frame
    height. None when the reference is full-bleed (no letterbox bars)."""
    try:
        import cv2
    except ImportError:
        return None
    probe_dir = settings.data_dir / "cache" / "band_probes"
    probe_dir.mkdir(parents=True, exist_ok=True)
    probe_key = hashlib.md5(f"{reference_path.resolve()}|{at_seconds:.3f}".encode()).hexdigest()[:16]
    probe_frame = probe_dir / f"{probe_key}.jpg"
    if not probe_frame.exists() and not _extract_single_frame(reference_path, at_seconds, probe_frame, settings):
        return None
    frame = cv2.imread(str(probe_frame))
    if frame is None:
        return None
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    row_means = gray.mean(axis=1)
    height = gray.shape[0]
    best_start, best_length = 0, 0
    run_start: int | None = None
    for index, value in enumerate([*row_means, 0.0]):
        if value > 20 and run_start is None:
            run_start = index
        elif value <= 20 and run_start is not None:
            if index - run_start > best_length:
                best_start, best_length = run_start, index - run_start
            run_start = None
    band_height = best_length / height
    if band_height < 0.2:
        return None
    return best_start / height, band_height


def crop_reference_cutaway(reference_path: Path, span: tuple[float, float], output_path: Path, settings: Settings) -> Path | None:
    """Caption-dodging crop of the reference's own cutaway footage. Always
    succeeds (falls back to an uncropped re-encode) so a span is never left
    empty — this is the guaranteed last rung of the sourcing ladder."""
    start, end = span
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_path.exists() and output_path.stat().st_size > 500:
        return output_path

    band = _detect_content_band(reference_path, (start + end) / 2, settings)
    if band is not None:
        band_top, band_height = band
        window_top = band_top + band_height * 0.14
        window_height = band_height * 0.40
        crop = f"crop=iw:ih*{window_height:.4f}:0:ih*{window_top:.4f}"
    else:
        # No detectable letterbox band (full-bleed reference) — dodge the
        # usual title/caption zones by keeping the middle 70% vertically.
        crop = "crop=iw:ih*0.70:0:ih*0.15"

    def _run(vf: str) -> bool:
        try:
            result = subprocess.run(
                [
                    settings.ffmpeg_path, "-y",
                    "-ss", f"{start:.3f}",
                    "-i", str(reference_path),
                    "-t", f"{max(0.05, end - start):.3f}",
                    "-vf", vf, "-an",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                    str(output_path),
                ],
                capture_output=True, text=True, timeout=90,
            )
        except subprocess.TimeoutExpired:
            return False
        return result.returncode == 0 and output_path.exists() and output_path.stat().st_size > 500

    if _run(crop):
        return output_path
    # Absolute last-ditch fallback: re-encode uncropped so this rung can never
    # fail. Captions may be visible, but a span is never left empty.
    return output_path if _run("null") else None


# ---------------------------------------------------------------------------
# Stage 7: placement
# ---------------------------------------------------------------------------


def _align_span_to_clip(ref_start: float, ref_end: float, ref_duration: float, clip_duration: float) -> tuple[float, float]:
    """Map a reference B-roll span onto OUR clip's timeline.

    Default rule: identical absolute timestamps. Only when the reference
    span's end would land past our clip's duration do we scale the span
    proportionally so the ratio of (span / total reference) is preserved.
    """
    if clip_duration <= 0:
        return (ref_start, max(ref_start, ref_end))
    if ref_end <= clip_duration:
        return (ref_start, ref_end)
    span = max(0.0, ref_end - ref_start)
    if ref_duration <= 0 or span <= 0:
        return (ref_start, clip_duration)
    span_frac = min(1.0, span / ref_duration)
    scaled_end = clip_duration
    scaled_start = max(0.0, scaled_end - span_frac * clip_duration)
    if scaled_end - scaled_start < MIN_OUTPUT_BROLL_SPAN:
        scaled_start = max(0.0, scaled_end - MIN_OUTPUT_BROLL_SPAN)
    return (scaled_start, scaled_end)


def _extract_segment(source: Path, duration: float, output_path: Path, settings: Settings) -> Path | None:
    """Simple ffmpeg trim of `source` to `duration` seconds (centered), or a
    looped extraction when the source itself is shorter than needed."""
    if output_path.exists() and output_path.stat().st_size > 500:
        return output_path
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        source_duration = probe_duration(source, settings)
    except Exception:
        source_duration = 0.0

    if source_duration >= duration > 0:
        start = max(0.0, (source_duration - duration) / 2)
        command = [
            settings.ffmpeg_path, "-y",
            "-ss", f"{start:.3f}", "-i", str(source),
            "-t", f"{duration:.3f}", "-an",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            str(output_path),
        ]
    else:
        command = [
            settings.ffmpeg_path, "-y",
            "-stream_loop", "-1", "-i", str(source),
            "-t", f"{max(duration, 0.1):.3f}", "-an",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            str(output_path),
        ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=90)
    except subprocess.TimeoutExpired:
        return None
    if result.returncode != 0 or not output_path.exists() or output_path.stat().st_size < 500:
        return None
    return output_path


def _span_profile_for(analysis: ReferenceAnalysis, index: int) -> SpanProfile:
    start, end, query = analysis.broll_spans[index]
    tags = analysis.broll_span_tags[index] if index < len(analysis.broll_span_tags) else {}
    if not isinstance(tags, dict):
        tags = {}
    return SpanProfile(
        start=start, end=end,
        subjects=list(tags.get("subjects", [])),
        setting=list(tags.get("setting", [])),
        action=list(tags.get("action", [])),
        category=tags.get("category") or "other",
        query=query or "",
    )


def _gather_span_pool(
    profile: SpanProfile,
    reference_path: Path,
    cache_dir: Path,
    library_index: list[LibraryClip],
    used_clips: set[Path],
    settings: Settings,
    pool_size: int,
    used_clips_lock: "threading.Lock | None" = None,
) -> list[tuple[Path, str, str]]:
    """Per-span candidate pool for variation rotation: Local -> YouTube ->
    reference-crop. Always returns at least one entry (guaranteed by the
    reference-crop rung), padded to `pool_size` by repeating the last entry.

    `used_clips_lock` is required when multiple `_gather_span_pool` calls run
    concurrently (the BROLL_RECOVERY per-span parallelization). Local library
    matching marks `used_clips` BEFORE releasing the lock so a concurrent
    span's `_rank_local` call sees the updated set; otherwise two spans could
    race-pick the same clip. YouTube / crop work runs after the lock is
    released so they overlap across spans."""
    import threading  # local import keeps this module's import graph tidy
    cache_dir.mkdir(parents=True, exist_ok=True)
    pool: list[tuple[Path, str, str]] = []
    span_duration = profile.end - profile.start
    # Very short spans are not worth a YouTube search: a 0.4s cutaway pays a
    # 20s preview download + frame extract + vision-score round-trip just to
    # produce something the renderer will only show for 400ms. Reference crop
    # is instant and visually fine for sub-second cutaways.
    skip_youtube = span_duration < MIN_YOUTUBE_SPAN_SECONDS

    if used_clips_lock is None:
        used_clips_lock = threading.Lock()

    with used_clips_lock:
        ranked_local = _rank_local(profile, library_index, used_clips)
        if ranked_local:
            picked = match_local(profile, library_index, used_clips, settings)
            if picked is not None:
                pool.append((picked.path, "local", f"library match: {picked.path.name}"))
                used_clips.add(picked.path.resolve())
                for clip, score in ranked_local:
                    if len(pool) >= pool_size or score <= 0:
                        break
                    if clip.path.resolve() == picked.path.resolve():
                        continue
                    # Reserve alternate inside the lock too — otherwise a
                    # concurrent span could pick the same alternate.
                    resolved = clip.path.resolve()
                    used_clips.add(resolved)
                    pool.append((clip.path, "local", f"library alternate: {clip.path.name}"))

    if not skip_youtube and len(pool) < pool_size:
        # YouTube work is the slow network-heavy rung; it runs OUTSIDE the
        # local-library lock so multiple spans can download in parallel.
        yt_path = search_youtube(profile, cache_dir / "youtube", settings)
        if yt_path is not None:
            pool.append((yt_path, "youtube", "matched YouTube clip"))

    if not pool:
        crop_path = cache_dir / "reference_crop.mp4"
        cropped = crop_reference_cutaway(reference_path, (profile.start, profile.end), crop_path, settings)
        if cropped is not None:
            pool.append((cropped, "reference_crop", "no local/YouTube match; cropped reference cutaway"))

    while pool and len(pool) < pool_size:
        pool.append(pool[-1])
    return pool


# B-roll spans shorter than this skip the YouTube search rung and go straight
# to the local library / reference-crop rungs. The cost of a 20s preview
# download + vision-score round-trip dwarfs the on-screen gain when the
# cutaway is sub-second. 1.0s keeps the existing 1s-span behavior intact
# while skipping the 0.4-0.7s fragments that show up in noisy references.
MIN_YOUTUBE_SPAN_SECONDS = 1.0


def fetch_broll_cut_variations(
    analysis: ReferenceAnalysis,
    reference_path: Path,
    clip_duration: float,
    cache_dir: Path,
    settings: Settings,
    variations: int = 1,
    diagnostics: list[BrollRecoveryDiagnostic] | None = None,
) -> list[list[BrollCut]]:
    """Produce `variations` B-roll cut lists sharing timeline placement but
    drawing from different source clips per span where alternatives exist.

    Timing is absolute, not proportional: a reference cut at 0.1s-2.0s becomes
    an output cut at 0.1s-2.0s, scaled only when the output is shorter.

    Per-span sourcing runs in parallel (max 4 workers) so an 8-span job's
    YouTube downloads + vision scorings overlap instead of running serially.
    Library matching is serialized through a lock (cheap section, no contention
    concern). YouTube/crop work runs concurrently outside the lock.
    """
    import threading
    from concurrent.futures import ThreadPoolExecutor

    variations = max(1, variations)
    if not analysis.broll_spans or analysis.duration <= 0:
        return [[] for _ in range(variations)]
    cache_dir.mkdir(parents=True, exist_ok=True)
    if diagnostics is not None:
        diagnostics.clear()
    library_index = build_library_index(settings)

    aligned: list[tuple[int, float, float, SpanProfile]] = []
    for index in range(len(analysis.broll_spans)):
        ref_start, ref_end, _query = analysis.broll_spans[index]
        out_start, out_end = _align_span_to_clip(ref_start, ref_end, analysis.duration, clip_duration)
        if out_end - out_start < MIN_OUTPUT_BROLL_SPAN:
            continue
        aligned.append((index, out_start, out_end, _span_profile_for(analysis, index)))

    used_clips: set[Path] = set()
    used_clips_lock = threading.Lock()
    pools: list[list[tuple[Path, str, str]]] = []
    # Cap workers at 4: more just hammers YouTube's per-IP rate limit and the
    # CPU ffmpeg pool, without meaningfully shrinking the longest span's
    # wall-clock cost.
    max_workers = min(4, max(1, len(aligned)))
    if max_workers == 1:
        for index, out_start, out_end, profile in aligned:
            pools.append(_gather_span_pool(
                profile, reference_path, cache_dir / f"span_{index}",
                library_index, used_clips, settings, pool_size=variations,
                used_clips_lock=used_clips_lock,
            ))
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(
                    _gather_span_pool,
                    profile, reference_path, cache_dir / f"span_{index}",
                    library_index, used_clips, settings, pool_size=variations,
                    used_clips_lock=used_clips_lock,
                ): index
                for index, _out_start, _out_end, profile in aligned
            }
            results_by_index: dict[int, list[tuple[Path, str, str]]] = {}
            for future, index in futures.items():
                try:
                    results_by_index[index] = future.result()
                except Exception:
                    logger.exception("B-roll span %d pool gather failed", index)
                    results_by_index[index] = []
            # Preserve original alignment order so per-span diagnostics line up.
            pools = [results_by_index[index] for index, _, _, _ in aligned]

    cut_lists: list[list[BrollCut]] = []
    for v in range(variations):
        cuts: list[BrollCut] = []
        for (index, out_start, out_end, profile), pool in zip(aligned, pools):
            if not pool:
                continue
            path, provider, reason = pool[min(v, len(pool) - 1)]
            segment = _extract_segment(path, out_end - out_start, cache_dir / f"span_{index}" / f"cut_v{v}.mp4", settings)
            if segment is None:
                continue
            cuts.append(BrollCut(start=out_start, end=out_end, clip_path=segment, query=profile.query))
            if diagnostics is not None and v == 0:
                diagnostics.append(BrollRecoveryDiagnostic(
                    start=out_start, end=out_end, query=profile.query,
                    provider=provider, source=str(path), match_type=provider,
                    selected=True, reason=reason,
                ))
        cut_lists.append(cuts)
    return cut_lists


def fetch_broll_cuts(
    analysis: ReferenceAnalysis,
    reference_path: Path,
    clip_duration: float,
    cache_dir: Path,
    settings: Settings,
    diagnostics: list[BrollRecoveryDiagnostic] | None = None,
) -> list[BrollCut]:
    return fetch_broll_cut_variations(
        analysis, reference_path, clip_duration, cache_dir, settings,
        variations=1, diagnostics=diagnostics,
    )[0]


# ---------------------------------------------------------------------------
# B-roll PACK — gather 1-2 trimmed clips per span WITHOUT inserting them
# ---------------------------------------------------------------------------


def _gather_pack_sources_for_span(
    span_index: int,
    out_start: float,
    out_end: float,
    profile: SpanProfile,
    reference_path: Path,
    cache_dir: Path,
    library_index: list[LibraryClip],
    used_clips: set[Path],
    used_clips_lock: "threading.Lock",
    settings: Settings,
    per_span: int,
) -> list[BrollPackItem]:
    """Per-span source gathering for the pack path, extracted so the parent
    loop can run it concurrently across spans. Same ladder (Local -> YouTube
    -> reference-crop) and same dedupe rules as the original inline loop.

    The local-library rung reserves each accepted clip into `used_clips`
    INSIDE the lock so a concurrent span's `_rank_local` sees the updated set
    and can't race-pick the same source. Without this, the parallelization
    would let span N re-pick what span 0 already locked in."""
    sources: list[tuple[Path, str]] = []

    # Rung 1 — local library (top ranked), up to per_span entries.
    with used_clips_lock:
        ranked_local = _rank_local(profile, library_index, used_clips)
        for clip, score in ranked_local:
            if score <= 0:
                break
            resolved = clip.path.resolve()
            if any(resolved == s.resolve() for s, _ in sources):
                continue
            used_clips.add(resolved)  # reserve BEFORE releasing the lock
            sources.append((clip.path, "local"))
            if len(sources) >= per_span:
                break

    # Rung 2 — YouTube previews. Skipped for sub-MIN_YOUTUBE_SPAN_SECONDS spans
    # where the preview-download + vision-score cost dwarfs the on-screen gain.
    if len(sources) < per_span and (out_end - out_start) >= MIN_YOUTUBE_SPAN_SECONDS:
        yt_remaining = per_span - len(sources)
        yt_dir = cache_dir / f"span_{span_index}" / "youtube"
        yt_candidates = search_youtube_candidates(
            profile, yt_dir, settings, count=yt_remaining
        )
        for yt_path in yt_candidates:
            resolved = yt_path.resolve()
            if any(resolved == s.resolve() for s, _ in sources):
                continue
            sources.append((yt_path, "youtube"))
            if len(sources) >= per_span:
                break

    # Rung 3 — guaranteed-last-rung reference crop. Always fills so a span is
    # never empty; dedupe keeps it from shadowing rank-1 when the ladder
    # already produced something better. Reference crops ARE per-span, so they
    # don't need cross-span dedupe bookkeeping.
    if len(sources) < per_span:
        crop_path = cache_dir / f"span_{span_index}" / "reference_crop.mp4"
        cropped = crop_reference_cutaway(
            reference_path,
            (profile.start, profile.end),
            crop_path,
            settings,
        )
        if cropped is not None:
            resolved = cropped.resolve()
            if not any(resolved == s.resolve() for s, _ in sources):
                sources.append((cropped, "reference_crop"))

    # Emit one BrollPackItem per source, in rank order. Library clips are
    # already reserved in used_clips from rung 1; the reference crop dedupes
    # against same-crop-from-other-spans in a follow-up pass.
    items: list[BrollPackItem] = []
    for rank, (source_path, provider) in enumerate(sources, start=1):
        output_segment = _extract_segment(
            source_path,
            out_end - out_start,
            cache_dir / f"span_{span_index}" / f"pack_opt{rank}.mp4",
            settings,
        )
        if output_segment is None:
            continue
        items.append(BrollPackItem(
            span_index=span_index,
            rank=rank,
            start=out_start,
            end=out_end,
            query=profile.query,
            provider=provider,
            clip_path=output_segment,
        ))
    return items


def gather_broll_pack(
    analysis: ReferenceAnalysis,
    reference_path: Path,
    clip_duration: float,
    cache_dir: Path,
    settings: Settings,
    per_span: int = 2,
) -> list[BrollPackItem]:
    """Build a downloadable B-roll pack for the reference's detected spans.

    Walk every output-timeline span (same alignment / skip rules as
    `fetch_broll_cut_variations`) and collect up to `per_span` distinct
    candidates in ladder order:

        1. Top local library ranked clips with score > 0 (reuses _rank_local
           + match_local with the shared used_clips set so adjacent spans
           don't double-pick the same clip).
        2. Top YouTube previews via `search_youtube_candidates`.
        3. `crop_reference_cutaway` as the always-succeeds last filler.

    Each accepted candidate is trimmed to the span's output duration with
    `_extract_segment` and saved to `cache_dir / span_{i} / pack_opt{rank}.mp4`.

    Same source video is NEVER emitted twice in one span's pack; if only 1
    distinct candidate exists the span gets exactly 1 entry (degraded, never
    padded by repeating — that would be useless duplicates for the user).
    The main rendered video gets NO B-roll cuts when this path is used; the
    pack IS the deliverable.

    Per-span work runs in parallel (max 4 workers) — same shape as
    `fetch_broll_cut_variations` for the same wall-clock reason.
    """
    import threading
    from concurrent.futures import ThreadPoolExecutor

    per_span = max(1, per_span)
    if not analysis.broll_spans or analysis.duration <= 0:
        return []

    cache_dir.mkdir(parents=True, exist_ok=True)
    library_index = build_library_index(settings)

    aligned: list[tuple[int, float, float, SpanProfile]] = []
    for index in range(len(analysis.broll_spans)):
        ref_start, ref_end, _query = analysis.broll_spans[index]
        out_start, out_end = _align_span_to_clip(ref_start, ref_end, analysis.duration, clip_duration)
        if out_end - out_start < MIN_OUTPUT_BROLL_SPAN:
            continue
        aligned.append((index, out_start, out_end, _span_profile_for(analysis, index)))

    used_clips: set[Path] = set()
    used_clips_lock = threading.Lock()

    max_workers = min(4, max(1, len(aligned)))
    if max_workers == 1:
        per_span_items = [
            _gather_pack_sources_for_span(
                span_index, out_start, out_end, profile,
                reference_path, cache_dir, library_index, used_clips,
                used_clips_lock, settings, per_span,
            )
            for span_index, out_start, out_end, profile in aligned
        ]
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(
                    _gather_pack_sources_for_span,
                    span_index, out_start, out_end, profile,
                    reference_path, cache_dir, library_index, used_clips,
                    used_clips_lock, settings, per_span,
                ): span_index
                for span_index, out_start, out_end, profile in aligned
            }
            per_span_items_by_index: dict[int, list[BrollPackItem]] = {}
            for future, span_index in futures.items():
                try:
                    per_span_items_by_index[span_index] = future.result()
                except Exception:
                    logger.exception("B-roll pack span %d gather failed", span_index)
                    per_span_items_by_index[span_index] = []
            per_span_items = [per_span_items_by_index[index] for index, _, _, _ in aligned]

    items: list[BrollPackItem] = []
    for sublist in per_span_items:
        items.extend(sublist)
    return items


def fetch_learned_broll_cuts(
    source_path: Path,
    broll_spans: list[tuple[float, float, str]],
    clip_duration: float,
    cache_dir: Path,
    settings: Settings,
) -> list[BrollCut]:
    """Source B-roll for a raw clip (no reference) at learned placements.
    There is no reference cutaway to fall back on, so a span with no
    local/YouTube match is left empty (A-roll stays)."""
    if not broll_spans or clip_duration <= 0:
        return []
    cache_dir.mkdir(parents=True, exist_ok=True)
    library_index = build_library_index(settings)
    used_clips: set[Path] = set()
    cuts: list[BrollCut] = []
    for index, (start, end, query) in enumerate(broll_spans):
        out_end = min(end, clip_duration)
        if out_end - start < MIN_OUTPUT_BROLL_SPAN:
            continue
        profile = SpanProfile(start=start, end=out_end, category="other", query=query or "")
        span_cache = cache_dir / f"span_{index}"
        span_cache.mkdir(parents=True, exist_ok=True)

        picked = match_local(profile, library_index, used_clips, settings)
        source: Path | None = None
        if picked is not None:
            source = picked.path
            used_clips.add(picked.path.resolve())
        else:
            source = search_youtube(profile, span_cache / "youtube", settings)
        if source is None:
            continue
        segment = _extract_segment(source, out_end - start, span_cache / "cut.mp4", settings)
        if segment is None:
            continue
        cuts.append(BrollCut(start=start, end=out_end, clip_path=segment, query=profile.query))
    return cuts
