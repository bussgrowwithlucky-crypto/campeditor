from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    groq_api_key: str = Field(default="", validation_alias="GROQ_API_KEY")
    groq_transcription_model: str = Field(
        default="whisper-large-v3-turbo", validation_alias="GROQ_TRANSCRIPTION_MODEL"
    )
    groq_vision_model: str = Field(
        default="meta-llama/llama-4-scout-17b-16e-instruct", validation_alias="GROQ_VISION_MODEL"
    )
    # NVIDIA NIM vision — OpenAI-compatible, GPU-accelerated, fast (~2.5s/call).
    # Used as the PRIMARY vision provider; Groq is the fallback.
    nvidia_api_key: str = Field(default="", validation_alias="NVIDIA_API_KEY")
    nvidia_base_url: str = Field(
        default="https://integrate.api.nvidia.com/v1", validation_alias="NVIDIA_BASE_URL"
    )
    nvidia_vision_model: str = Field(
        default="meta/llama-3.2-11b-vision-instruct", validation_alias="NVIDIA_VISION_MODEL"
    )
    # Secondary NVIDIA API key — used only when the primary rate-limits (429) or
    # errors. Same model/endpoint. Optional: empty = no secondary key.
    nvidia_fallback_api_key: str = Field(default="", validation_alias="NVIDIA_FALLBACK_API_KEY")
    # Tertiary NVIDIA API key — last-resort before Groq. Used when both primary
    # and secondary NVIDIA keys fail (e.g. both rate-limited). Same model/endpoint.
    nvidia_fallback_api_key_2: str = Field(default="", validation_alias="NVIDIA_FALLBACK_API_KEY_2")
    # Quaternary NVIDIA API key — fourth fallback before Groq. Used when all
    # three earlier NVIDIA keys fail (rate-limited or down).
    nvidia_fallback_api_key_3: str = Field(default="", validation_alias="NVIDIA_FALLBACK_API_KEY_3")

    # Google Gemini vision — tried FIRST in the _vision ladder (before NVIDIA),
    # via Google's OpenAI-compatible endpoint so it reuses the same client path.
    # gemini-2.5-flash is fast and strong at scene/subject description. Empty
    # key = Gemini skipped, ladder falls straight to NVIDIA → Groq.
    gemini_api_key: str = Field(default="", validation_alias="GEMINI_API_KEY")
    gemini_base_url: str = Field(
        default="https://generativelanguage.googleapis.com/v1beta/openai/",
        validation_alias="GEMINI_BASE_URL",
    )
    gemini_vision_model: str = Field(
        default="gemini-2.5-flash", validation_alias="GEMINI_VISION_MODEL"
    )

    # Local Ollama fallback — the LAST rung of both the vision and text
    # ladders. Used automatically when every cloud provider is down or
    # rate-limited (e.g. Groq daily quota exhausted), so the pipeline keeps
    # working offline at reduced quality/speed. Empty model name = rung
    # disabled. The base URL is Ollama's OpenAI-compatible endpoint.
    ollama_base_url: str = Field(
        default="http://localhost:11434/v1", validation_alias="OLLAMA_BASE_URL"
    )
    ollama_vision_model: str = Field(default="", validation_alias="OLLAMA_VISION_MODEL")
    ollama_text_model: str = Field(default="", validation_alias="OLLAMA_TEXT_MODEL")

    # OpenAI-compatible chat completions provider for title generation + clip
    # selection. Default is byNara's router (Telegram-gated, free with an active
    # link) carrying Claude Sonnet 4.5 — swap these three to point at any other
    # OpenAI-compatible endpoint (OpenRouter, Groq, etc).
    llm_api_key: str = Field(default="", validation_alias="LLM_API_KEY")
    llm_base_url: str = Field(
        default="https://router.bynara.id/v1", validation_alias="LLM_BASE_URL"
    )
    llm_model: str = Field(default="claude-sonnet-4.5", validation_alias="LLM_MODEL")
    # Used automatically when the primary model/provider fails. Empty = no fallback.
    llm_fallback_model: str = Field(default="", validation_alias="LLM_FALLBACK_MODEL")
    # Cross-provider backstop: when the LLM endpoint above is down entirely,
    # chat calls fall back to this model on Groq (same key as transcription).
    groq_chat_fallback_model: str = Field(
        default="llama-3.3-70b-versatile", validation_alias="GROQ_CHAT_FALLBACK_MODEL"
    )

    ffmpeg_path: str = Field(default="ffmpeg", validation_alias="FFMPEG_PATH")
    ffprobe_path: str = Field(default="ffprobe", validation_alias="FFPROBE_PATH")
    ytdlp_cookies_file: Path | None = Field(default=None, validation_alias="YTDLP_COOKIES_FILE")
    ytdlp_cookies_from_browser: str = Field(
        default="chrome", validation_alias="YTDLP_COOKIES_FROM_BROWSER"
    )
    broll_library_dir: Path = Field(default=Path("data/broll_library"), validation_alias="BROLL_LIBRARY_DIR")
    # YouTube Data API v3 keys for B-roll SEARCH (metadata only; yt-dlp still
    # downloads the chosen clip). When set, search goes through the Data API for
    # better-ranked, faster results, falling back to yt-dlp ytsearch on error /
    # quota. Two keys so a rate-limited (429) or quota-exceeded (403) primary
    # rotates to the secondary. Empty = pure yt-dlp ytsearch (no key needed).
    youtube_data_api_key: str = Field(default="", validation_alias="YOUTUBE_DATA_API_KEY")
    youtube_data_api_key_2: str = Field(default="", validation_alias="YOUTUBE_DATA_API_KEY_2")
    # Maximum word count for a B-roll search query sent to YouTube. Vision
    # descriptions are already short, but this enforces the user's spec
    # ("≤8-word search term") and tightens ytsearch relevance — long phrases
    # return fewer and lower-quality hits on yt-dlp's text index.
    broll_query_max_words: int = Field(
        default=8, validation_alias="BROLL_QUERY_MAX_WORDS"
    )
    # Local-library match score floor (see app/broll.py's match_local): below
    # this, the cheap category/subject/setting score alone isn't trusted and
    # the span falls through to the YouTube rung instead.
    broll_local_match_threshold: float = Field(
        default=0.35, validation_alias="BROLL_LOCAL_MATCH_THRESHOLD"
    )
    # MDX-Net instrumental extraction for Replicate music (small ONNX model, CPU,
    # auto-downloaded on first use). Set false to force the gap-loop fallback.
    music_separation: bool = Field(default=True, validation_alias="MUSIC_SEPARATION")

    # Global B-roll learning: every analyzed reference updates a running profile
    # of B-roll placement/queries. Raw uploads (no reference) reuse the profile
    # to synthesize B-roll spans so they inherit the learned pattern.
    broll_learning_enabled: bool = Field(
        default=True, validation_alias="BROLL_LEARNING_ENABLED"
    )

    # Comma-separated list of allowed CORS origins for a split deploy (frontend
    # on Netlify, backend on Render). Default "*" is fine for local/all-in-one.
    cors_allow_origins: str = Field(default="*", validation_alias="CORS_ALLOW_ORIGINS")

    data_dir: Path = Field(default=Path("data"), validation_alias="CAMPEDITOR_DATA_DIR")
    max_upload_mb: int = Field(default=500, validation_alias="CAMPEDITOR_MAX_UPLOAD_MB")
    worker_count: int = Field(default=2, validation_alias="CAMPEDITOR_WORKER_COUNT")

    # Single-upload variation count: every single-upload job renders this many
    # variations (same music + caption + B-roll placement timeline, different
    # title text and different B-roll source clips). Bulk-upload jobs always
    # render exactly 1 per pair regardless of this setting.
    variation_count: int = Field(default=1, validation_alias="VARIATION_COUNT")
    # When true, bulk-upload jobs are queued into a single Pipeline; otherwise
    # the flag is purely informational to skip variation generation. Bulk
    # uploads always force variation_count = 1, so the default here is the
    # render count for normal single-upload jobs.
    max_bulk_pairs: int = Field(default=100, validation_alias="MAX_BULK_PAIRS")

    auto_clip_scan_seconds: float = Field(default=600.0, validation_alias="CAMPEDITOR_AUTO_CLIP_SCAN_SECONDS")
    auto_clip_target_seconds: float = Field(default=15.0, validation_alias="CAMPEDITOR_AUTO_CLIP_TARGET_SECONDS")
    auto_clip_min_seconds: float = Field(default=8.0, validation_alias="CAMPEDITOR_AUTO_CLIP_MIN_SECONDS")
    auto_clip_max_seconds: float = Field(default=30.0, validation_alias="CAMPEDITOR_AUTO_CLIP_MAX_SECONDS")

    @property
    def youtube_data_api_keys(self) -> list[str]:
        """Non-empty YouTube Data API v3 keys, primary first, for rotation on
        429 / quota-exceeded."""
        return [k for k in (self.youtube_data_api_key, self.youtube_data_api_key_2) if k.strip()]


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    settings.broll_library_dir.mkdir(parents=True, exist_ok=True)
    return settings
