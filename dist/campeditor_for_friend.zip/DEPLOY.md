# Deploying campeditor

campeditor is a long-running FastAPI server that shells out to **ffmpeg**, downloads
multi-GB video with yt-dlp, and takes 5–10 minutes per render. That shape decides
everything below:

- **Render** (or any container/VM host) runs the whole app well — it is the recommended target.
- **Netlify** only runs short-lived serverless functions (10 s free / 26 s Pro) with no
  ffmpeg and no persistent disk, so it **cannot run the backend**. Use Netlify only for the
  static frontend, pointed at the Render backend.

The recommended setup is therefore a **split**: backend on Render, frontend on Netlify.

---

## 1. Backend on Render (recommended)

The repo ships a `Dockerfile` that installs ffmpeg — use it (Render's native Python
runtime has no ffmpeg).

1. Push this repo to GitHub.
2. Render → **New → Web Service** → connect the repo.
3. **Runtime: Docker** (Render auto-detects the `Dockerfile`). Leave build/start commands blank —
   the Dockerfile's `CMD` binds `0.0.0.0:$PORT`.
4. Instance type: at least **Standard** (renders are CPU/RAM heavy; Free/Starter will OOM or
   time out on `audio-separator` and ffmpeg).
5. **Environment variables** — copy every key from your local `.env` into Render's
   *Environment* tab. At minimum:
   - `NVIDIA_API_KEY`, `NVIDIA_FALLBACK_API_KEY`, `NVIDIA_FALLBACK_API_KEY_2`, `NVIDIA_VISION_MODEL`
   - `GROQ_API_KEY`
   - `LLM_API_KEY`, `LLM_BASE_URL`, `LLM_MODEL`
   - `PEXELS_API_KEY`
   - `BROLL_*` knobs you have customized, `VARIATION_COUNT`, `MAX_BULK_PAIRS`, `BROLL_LEARNING_ENABLED`
   - `CORS_ALLOW_ORIGINS=https://<your-site>.netlify.app` (see the split section below)
6. **yt-dlp cookies:** add `data/youtube-cookies.txt` as a Render **Secret File**, then set
   `YTDLP_COOKIES_FILE=/etc/secrets/youtube-cookies.txt`. (`YTDLP_COOKIES_FROM_BROWSER`
   only works on a machine with Chrome logged in — it does nothing on a server.)
7. **Persistent storage:** the container filesystem is wiped on every deploy. Job outputs
   under `data/` therefore do **not** survive a redeploy. For real use, attach a Render
   **Disk** mounted at `/app/data` (set `CAMPEDITOR_DATA_DIR=/app/data`), or move outputs
   to external object storage (S3/R2). Without one, treat renders as ephemeral — download
   them before the next deploy.

> ⚠️ **Rotate your API keys.** The NVIDIA/Groq/Pexels/LLM keys currently in `.env` were
> pasted in plaintext in chat and must be considered compromised. Generate fresh keys and
> put them only in Render's Environment tab — never commit `.env`.

### Render without Docker (fallback)

If you must use Render's native Python env instead of Docker, ffmpeg is not preinstalled.
Add a build step that vendors a static ffmpeg (e.g. `imageio-ffmpeg`) and set `FFMPEG_PATH`
to its path. The Docker route above avoids this entirely — prefer it.

---

## 2. Frontend on Netlify (static, points at Render)

The frontend is plain static files in `static/` (`index.html`, `app.js`, `styles.css`) and
already honors a global `window.API_BASE` (defaults to `""` = same origin, so local dev is
unchanged).

1. Netlify → **Add new site → Deploy manually** (or connect the repo).
2. **Publish directory:** `static`. **Build command:** none.
3. Tell the frontend where the backend lives — add this line to `static/index.html`
   **before** `<script src="/app.js"></script>`:
   ```html
   <script>window.API_BASE = "https://<your-service>.onrender.com";</script>
   ```
4. On the backend (Render), set `CORS_ALLOW_ORIGINS` to your Netlify origin, e.g.
   `CORS_ALLOW_ORIGINS=https://<your-site>.netlify.app`. Multiple origins are
   comma-separated. The FastAPI app reads this and configures `CORSMiddleware`.

Local / all-in-one deploys need none of this: leave `window.API_BASE` unset and
`CORS_ALLOW_ORIGINS=*` (the default), and the backend serves `static/` itself at `/`.

---

## 3. Why not all-on-Netlify

Splitting each endpoint into a Netlify Function would require bundling an ffmpeg binary into
every function, adding external storage (functions are stateless), and — fatally — the
render pipeline runs for minutes while Netlify Functions cap at 10 s (free) / 26 s (Pro).
It is not viable. Run the backend on Render.

---

## Quick reference

| Concern            | Local / all-in-one         | Split (Render + Netlify)                    |
| ------------------ | -------------------------- | ------------------------------------------- |
| Backend            | `uvicorn app.main:app`     | Render Web Service (Docker)                 |
| Frontend           | served by backend at `/`   | Netlify static (`static/`)                  |
| `window.API_BASE`  | unset (`""`)               | `https://<service>.onrender.com`            |
| `CORS_ALLOW_ORIGINS` | `*`                      | `https://<site>.netlify.app`                |
| ffmpeg             | on PATH                    | installed by `Dockerfile`                   |
| Renders persist?   | yes (local disk)           | only with a Render Disk at `/app/data`      |
