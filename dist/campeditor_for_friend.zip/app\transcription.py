"""Groq Whisper transcription with word-level timestamps.

The audio slice (start..end) is extracted locally with FFmpeg first, so all
returned timestamps are relative to the trimmed clip — which is also how the
render timeline starts (ffmpeg -ss <start>). No chunking: clips are 12-15s.

Never raises: returns an empty Transcript on API failure so the pipeline can
still render (without captions) instead of dying.
"""

import logging
import subprocess
from pathlib import Path

from app.config import Settings
from app.models import Transcript, TranscriptSegment, TranscriptWord

logger = logging.getLogger(__name__)


def transcribe(source_path: Path, start: float, end: float, work_dir: Path, settings: Settings) -> Transcript:
    if not settings.groq_api_key:
        logger.warning("GROQ_API_KEY not set - skipping transcription")
        return Transcript()
    try:
        audio_path = _extract_audio(source_path, start, end, work_dir, settings)
    except Exception:
        logger.exception("Audio extraction failed")
        return Transcript()
    try:
        return _transcribe_with_groq(audio_path, settings)
    except Exception:
        logger.exception("Groq transcription failed")
        return Transcript()


def _extract_audio(source_path: Path, start: float, end: float, work_dir: Path, settings: Settings) -> Path:
    audio_path = work_dir / "audio.wav"
    command = [
        settings.ffmpeg_path,
        "-y",
        "-ss", f"{start:.3f}",
        "-i", str(source_path),
        "-t", f"{end - start:.3f}",
        "-vn", "-ac", "1", "-ar", "16000",
        str(audio_path),
    ]
    result = subprocess.run(command, capture_output=True, text=True, timeout=120)
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg audio extraction failed: {result.stderr[-500:]}")
    return audio_path


def _transcribe_with_groq(audio_path: Path, settings: Settings) -> Transcript:
    from openai import OpenAI

    client = OpenAI(api_key=settings.groq_api_key, base_url="https://api.groq.com/openai/v1")
    with audio_path.open("rb") as audio_file:
        result = client.audio.transcriptions.create(
            model=settings.groq_transcription_model,
            file=audio_file,
            response_format="verbose_json",
            timestamp_granularities=["word", "segment"],
        )

    segments: list[TranscriptSegment] = []
    for segment in getattr(result, "segments", None) or []:
        start = float(_field(segment, "start", 0))
        end = float(_field(segment, "end", 0))
        text = str(_field(segment, "text", "")).strip()
        if text:
            segments.append(TranscriptSegment(start=start, end=end, text=text))

    words: list[TranscriptWord] = []
    for word in getattr(result, "words", None) or []:
        token = str(_field(word, "word", "")).strip()
        if token:
            words.append(
                TranscriptWord(
                    word=token,
                    start=float(_field(word, "start", 0)),
                    end=float(_field(word, "end", 0)),
                )
            )

    if not words and segments:
        words = _words_from_segments(segments)
    return Transcript(words=words, segments=segments)


def _field(item, name: str, default):
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)


def _words_from_segments(segments: list[TranscriptSegment]) -> list[TranscriptWord]:
    """Groq occasionally omits word timestamps: split each segment's time range
    across its words proportionally to character length."""
    words: list[TranscriptWord] = []
    for segment in segments:
        tokens = segment.text.split()
        if not tokens:
            continue
        total_chars = sum(len(token) for token in tokens) or 1
        duration = max(0.1, segment.end - segment.start)
        cursor = segment.start
        for token in tokens:
            share = duration * len(token) / total_chars
            words.append(TranscriptWord(word=token, start=cursor, end=cursor + share))
            cursor += share
    return words
