"""Reference-short reverse engineering for Replicate mode.

Given a finished viral short (the "reference"), figure out how it was edited:
- read its on-screen title with vision (so the title LLM can clone the pattern),
- find its B-roll cutaways and describe/source matching footage (app/broll.py),
- pull background music from speech-free stretches of its audio,
- detect any logo/image overlay so the renderer can reproduce it.

B-roll detection, description, and sourcing live in app/broll.py; this module
only assembles the ReferenceAnalysis and owns everything else (title, music,
logo, reference download).
"""

import logging
import re
import subprocess
import sys
import threading
from pathlib import Path

from app.broll import describe_spans, detect_broll_spans, extract_reference_frames
from app.broll import _vision as _broll_vision
from app.config import Settings
from app.models import LogoOverlay, ReferenceAnalysis, Transcript
from app.rendering import probe_duration
from app.transcription import transcribe

logger = logging.getLogger(__name__)

MAX_ANALYZE_SECONDS = 60.0
MIN_MUSIC_GAP = 3.0

# ONNX Runtime's CPU arena can fail to allocate ("bad allocation" /
# BFCArena::AllocateRawInternal) when two MDX-Net separation sessions run at
# the same time on the same process, which happens routinely with
# worker_count > 1 (two jobs analyzing their reference concurrently). That
# exception was previously swallowed and silently fell back to the
# speech-gap method, which finds nothing on continuous-speech references -
# music extraction failed with no visible error. Serializing just this
# inference call fixes it without losing any other stage's concurrency.
_SEPARATION_LOCK = threading.Lock()


def download_reference(url: str, work_dir: Path, settings: Settings) -> Path:
    """Download a reference short from a URL (YouTube/Shorts/etc.) via yt-dlp."""
    url = url.strip()
    if not url.lower().startswith(("http://", "https://")):
        raise ValueError("Reference link must be an http(s) URL")
    target = work_dir / "reference.mp4"
    target.unlink(missing_ok=True)
    command = _yt_dlp_command(url, target, settings)
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=300,
    )
    if result.returncode != 0 and _is_browser_cookie_error(result.stderr):
        # A locked/unreadable/undecryptable browser cookie DB shouldn't kill
        # public downloads. yt-dlp #10927: Chrome 130+ DPAPI cookie encryption
        # breaks "--cookies-from-browser chrome" — the stderr says "decrypt with
        # DPAPI" (no "cookie" word), so a naive substring check lets the error
        # propagate and fail the whole job. Drop cookie args and retry.
        cookieless = [arg for index, arg in enumerate(command) if not (
            arg in ("--cookies", "--cookies-from-browser")
            or (index > 0 and command[index - 1] in ("--cookies", "--cookies-from-browser"))
        )]
        result = subprocess.run(cookieless, capture_output=True, text=True, timeout=300)
    if result.returncode != 0 or not target.exists() or target.stat().st_size < 10_000:
        raise RuntimeError(f"Reference download failed: {result.stderr[-400:]}")
    return target


def _yt_dlp_command(url: str, target: Path, settings: Settings) -> list[str]:
    command = [
        sys.executable,
        "-m",
        "yt_dlp",
        "--no-playlist",
        "-f",
        "bv*[height<=1920]+ba/b",
        "--merge-output-format",
        "mp4",
        "-o",
        str(target),
    ]
    cookies_file = settings.ytdlp_cookies_file
    if cookies_file and cookies_file.exists():
        command.extend(["--cookies", str(cookies_file)])
    elif settings.ytdlp_cookies_from_browser.strip():
        command.extend(["--cookies-from-browser", settings.ytdlp_cookies_from_browser.strip()])
    command.append(url)
    return command


def _is_browser_cookie_error(stderr: str) -> bool:
    lowered = stderr.lower()
    if "could not copy" in lowered and "cookie" in lowered:
        return True
    if "failed to decrypt" in lowered and "dpapi" in lowered:
        return True
    if "extract cookies" in lowered and "browser" in lowered:
        return True
    return False


def analyze_reference(reference_path: Path, work_dir: Path, settings: Settings) -> ReferenceAnalysis:
    duration = probe_duration(reference_path, settings)
    ref_dir = work_dir / "reference"
    ref_dir.mkdir(parents=True, exist_ok=True)

    transcript = transcribe(reference_path, 0.0, duration, ref_dir, settings)
    frames = extract_reference_frames(reference_path, min(duration, MAX_ANALYZE_SECONDS), ref_dir / "frames", settings)

    spans = detect_broll_spans(frames)
    span_profiles = describe_spans(spans, frames, settings)
    broll_spans = [(profile.start, profile.end, profile.query) for profile in span_profiles]
    broll_span_tags = [
        {
            "subjects": profile.subjects,
            "setting": profile.setting,
            "action": profile.action,
            "category": profile.category,
        }
        for profile in span_profiles
    ]
    broll_query_source = ["vision" if profile.query else "" for profile in span_profiles]

    music_path = _extract_music(reference_path, transcript, duration, ref_dir, settings)
    music_volume_db = _mean_volume_db(music_path, settings) if music_path else None
    logo_overlay = _detect_logo_overlay(frames, settings)

    return ReferenceAnalysis(
        duration=duration,
        title_text=_read_title(reference_path, ref_dir, settings),
        transcript_text=transcript.text,
        broll_spans=broll_spans,
        broll_span_tags=broll_span_tags,
        broll_query_source=broll_query_source,
        music_path=music_path,
        music_volume_db=music_volume_db,
        logo_overlay=logo_overlay,
    )


def _read_title(reference_path: Path, ref_dir: Path, settings: Settings) -> str:
    """Read the styled on-screen title from an early frame (top 40% of the canvas)."""
    title_frame = ref_dir / "title_frame.jpg"
    result = subprocess.run(
        [
            settings.ffmpeg_path,
            "-y",
            "-ss", "1.0",
            "-i", str(reference_path),
            "-frames:v", "1",
            "-vf", "crop=iw:ih*0.4:0:0,scale=720:-1",
            str(title_frame),
        ],
        capture_output=True,
        text=True,
        timeout=60,
    )
    if result.returncode != 0 or not title_frame.exists():
        return ""
    try:
        text = _broll_vision(
            title_frame,
            "This is the top part of a vertical short-form video. Read the styled on-screen "
            "TITLE text (the headline overlay). Reply with ONLY the exact title text on one "
            "line. If there is no title text, reply NONE.",
            settings,
        )
        text = " ".join(text.split())
        if not text or text.upper() == "NONE" or len(text) > 120:
            return ""
        return text
    except Exception:
        logger.exception("Title vision read failed")
        return ""


# ---------------------------------------------------------------------------
# Music
# ---------------------------------------------------------------------------


def _extract_music(
    reference_path: Path,
    transcript: Transcript,
    duration: float,
    ref_dir: Path,
    settings: Settings,
) -> Path | None:
    """The reference's music WITHOUT its voiceover, timestamps preserved.

    Primary path: MDX-Net vocal separation (small ONNX model, CPU) over the full
    reference audio — the instrumental keeps the exact same timeline, so music
    hits land at the same timestamps as the reference. Fallback when separation
    is unavailable/fails: the old longest-speech-free-gap loop.
    """
    separated = _separate_instrumental(reference_path, ref_dir, settings)
    if separated is not None:
        return separated

    if not transcript.words:
        # No speech at all: the whole audio track is effectively music.
        gap = (0.0, min(duration, 20.0))
    else:
        gaps: list[tuple[float, float]] = []
        previous_end = 0.0
        for word in transcript.words:
            if word.start - previous_end >= MIN_MUSIC_GAP:
                gaps.append((previous_end, word.start))
            previous_end = max(previous_end, word.end)
        if duration - previous_end >= MIN_MUSIC_GAP:
            gaps.append((previous_end, duration))
        if not gaps:
            return None
        gap = max(gaps, key=lambda g: g[1] - g[0])

    music_path = ref_dir / "music.m4a"
    result = subprocess.run(
        [
            settings.ffmpeg_path,
            "-y",
            "-ss", f"{gap[0]:.3f}",
            "-i", str(reference_path),
            "-t", f"{gap[1] - gap[0]:.3f}",
            "-vn",
            "-c:a", "aac",
            "-b:a", "160k",
            str(music_path),
        ],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if result.returncode != 0 or not music_path.exists() or music_path.stat().st_size < 5_000:
        return None
    return music_path


def _separate_instrumental(reference_path: Path, ref_dir: Path, settings: Settings) -> Path | None:
    """MDX-Net (ONNX, CPU) instrumental extraction of the FULL reference audio.

    Returns an m4a whose timeline is 1:1 with the reference, or None when the
    package/model is unavailable, separation fails, or the instrumental is
    basically silence (reference had no real music under the voice).
    """
    if not settings.music_separation:
        return None
    try:
        import audio_separator  # noqa: F401
    except ImportError:
        logger.warning("audio-separator not installed - music falls back to gap extraction")
        return None

    music_path = ref_dir / "music_instrumental.m4a"
    if music_path.exists() and music_path.stat().st_size > 5_000:
        return music_path
    try:
        wav = ref_dir / "ref_audio.wav"
        extract = subprocess.run(
            [
                settings.ffmpeg_path,
                "-y",
                "-i", str(reference_path),
                "-vn", "-ac", "2", "-ar", "44100",
                str(wav),
            ],
            capture_output=True,
            text=True,
            timeout=180,
        )
        if extract.returncode != 0 or not wav.exists():
            return None

        separated_dir = ref_dir / "separated"
        separated_dir.mkdir(exist_ok=True)
        # Run the actual separation in its own subprocess, one at a time.
        # In-process ONNX Runtime sessions were observed to fail with
        # "BFCArena::AllocateRawInternal Failed to allocate memory" on
        # back-to-back calls within the same long-lived server process -
        # a lock alone wasn't enough because the prior session's arena
        # memory wasn't reliably released before the next one started. A
        # subprocess gets a clean memory slate every time; the lock keeps
        # peak memory bounded to one separation at a time on this machine.
        with _SEPARATION_LOCK:
            proc = subprocess.run(
                [
                    sys.executable, "-m", "app._music_separator_worker",
                    str(wav),
                    str(settings.data_dir / "models"),
                    str(separated_dir),
                    "UVR-MDX-NET-Inst_HQ_3.onnx",
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )
        if proc.returncode != 0:
            logger.warning("Music separation subprocess failed: %s", proc.stderr[-800:])
            return None
        instrumental_name = proc.stdout.strip().splitlines()[-1] if proc.stdout.strip() else ""
        instrumental = separated_dir / instrumental_name if instrumental_name else None
        if instrumental is None or not instrumental.exists():
            return None
        if _mean_volume_db(instrumental, settings) < -45.0:
            logger.info("Instrumental is near-silent - reference has no real music")
            return None
        encode = subprocess.run(
            [
                settings.ffmpeg_path,
                "-y",
                "-i", str(instrumental),
                "-c:a", "aac",
                "-b:a", "160k",
                str(music_path),
            ],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if encode.returncode != 0 or not music_path.exists() or music_path.stat().st_size < 5_000:
            return None
        logger.info("Extracted instrumental music track (timestamps preserved)")
        return music_path
    except Exception:
        logger.exception("Music separation failed - falling back to gap extraction")
        return None


def _mean_volume_db(audio_path: Path, settings: Settings) -> float:
    result = subprocess.run(
        [
            settings.ffmpeg_path,
            "-i", str(audio_path),
            "-af", "volumedetect",
            "-f", "null",
            "-",
        ],
        capture_output=True,
        text=True,
        timeout=120,
    )
    match = re.search(r"mean_volume:\s*(-?[\d.]+)\s*dB", result.stderr)
    return float(match.group(1)) if match else -100.0


# ---------------------------------------------------------------------------
# Logo / image overlay detection
# ---------------------------------------------------------------------------


# OpenCV's template matcher scores for a match; below this it's noise, above
# MATCH_ACCEPT we're confident, in between we treat the strongest hit as
# "plausible" and accept it when the user uploaded a reference image.
LOGO_MATCH_NOISE = 0.55
LOGO_MATCH_ACCEPT = 0.72
# Logo stickers are tiny in vertical short-form — typical max 22% of frame
# width. Outside this size band we treat the hit as a face / on-screen text.
LOGO_MIN_FRAC = 0.04
LOGO_MAX_FRAC = 0.30
# Per-frame search scales; resizes the reference frame, not the template, so a
# single template lookup still finds the logo at a few plausible sizes.
LOGO_TEMPLATE_SCALES = (0.65, 0.8, 1.0, 1.25, 1.55)


def _detect_logo_overlay(
    frames: list[Path],
    settings: Settings,
    user_logo: Path | None = None,
) -> "LogoOverlay | None":
    """Find a logo / image overlay in the reference, return its position+opacity.

    Two strategies:
    1. If the user supplied a reference logo image, slide it across every
       frame and average the strongest hit's box (template matching).
    2. Otherwise, look for a *static* element that appears in the same place
       in every frame but is NOT a face — that's a watermark or channel logo.

    Opacity is estimated by comparing the logo region to the same region in a
    frame that doesn't have the logo (taken as the median of the rest of the
    video), assuming the logo is a partial-alpha blend.
    """
    if not frames:
        return None
    try:
        import cv2
        import numpy as np
    except ImportError:
        return None

    logo_image: "np.ndarray | None" = None
    source_aspect = 1.0
    if user_logo and user_logo.exists():
        loaded = cv2.imread(str(user_logo), cv2.IMREAD_UNCHANGED)
        if loaded is not None:
            logo_image = _normalize_logo_image(loaded, cv2, np)
            if logo_image is not None:
                source_aspect = logo_image.shape[1] / max(1, logo_image.shape[0])

    if logo_image is not None:
        box = _slide_logo_template(frames, logo_image, cv2, np)
        if box is None:
            return None
        x_frac, y_frac, w_frac, h_frac = box
        opacity = _estimate_overlay_opacity(frames, x_frac, y_frac, w_frac, h_frac, cv2, np)
        return LogoOverlay(
            x=x_frac,
            y=y_frac,
            width=w_frac,
            height=h_frac,
            opacity=opacity,
            source_aspect=source_aspect,
        )

    return _detect_static_overlay(frames, cv2, np)


def _normalize_logo_image(loaded, cv2, np):
    """Strip alpha, return a single-channel grayscale logo on a black canvas.

    cv2.IMREAD_UNCHANGED gives us BGRA; we drop the alpha, normalize size, and
    keep a wide aspect band so transparent PNG logos match against their
    actual silhouette rather than their transparent background."""
    if loaded.ndim == 3 and loaded.shape[2] == 4:
        bgr = loaded[:, :, :3]
        alpha = loaded[:, :, 3]
        # Where the alpha is low, treat the pixel as black so the matcher
        # doesn't lock onto a transparent corner.
        bgr = np.where(alpha[:, :, None] > 32, bgr, 0)
    else:
        bgr = loaded
    height, width = bgr.shape[:2]
    target_w = 96
    scale = target_w / max(1, width)
    resized = cv2.resize(bgr, (target_w, max(1, int(height * scale))))
    if resized.ndim == 3:
        return cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
    return resized


def _slide_logo_template(frames: list[Path], logo_gray, cv2, np):
    """Template-match the logo in every frame, return the most common box.

    Returns (x_frac, y_frac, w_frac, h_frac) in 0..1 of frame size, or None if
    no frame produced a confident match. We average the top matches to ride
    out any single-frame false positives (a face briefly occluding the logo,
    a frame skip, etc).
    """
    template_h, template_w = logo_gray.shape[:2]
    hits: list[tuple[float, float, float, float, float]] = []  # x, y, w, h, score
    for frame_path in frames:
        frame = cv2.imread(str(frame_path), cv2.IMREAD_GRAYSCALE)
        if frame is None:
            continue
        fh, fw = frame.shape[:2]
        if fh < template_h * 2 or fw < template_w * 2:
            continue
        best_for_frame: tuple[float, float, float, float, float] | None = None
        for scale in LOGO_TEMPLATE_SCALES:
            tw = int(template_w * scale)
            th = int(template_h * scale)
            if tw < 8 or th < 8 or tw >= fw or th >= fh:
                continue
            resized = cv2.resize(frame, (fw, fh))
            result = cv2.matchTemplate(resized, cv2.resize(logo_gray, (tw, th)), cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(result)
            if max_val < LOGO_MATCH_NOISE:
                continue
            x, y = max_loc
            w_frac = tw / fw
            h_frac = th / fh
            if not (LOGO_MIN_FRAC <= w_frac <= LOGO_MAX_FRAC and LOGO_MIN_FRAC <= h_frac <= LOGO_MAX_FRAC):
                continue
            candidate = (x / fw, y / fh, w_frac, h_frac, float(max_val))
            if best_for_frame is None or candidate[4] > best_for_frame[4]:
                best_for_frame = candidate
        if best_for_frame is not None and best_for_frame[4] >= LOGO_MATCH_ACCEPT:
            hits.append(best_for_frame[:4])

    if not hits:
        # No "definitely matches" hits. Try the best of the noise band; if
        # many weak hits cluster in the same region, the logo is probably
        # still there but the user-supplied image is slightly off (compressed
        # / re-exported). Cluster the plausible hits and accept the densest.
        weak_hits: list[tuple[float, float, float, float]] = []
        for frame_path in frames:
            frame = cv2.imread(str(frame_path), cv2.IMREAD_GRAYSCALE)
            if frame is None:
                continue
            fh, fw = frame.shape[:2]
            for scale in LOGO_TEMPLATE_SCALES:
                tw = int(template_w * scale)
                th = int(template_h * scale)
                if tw < 8 or th < 8 or tw >= fw or th >= fh:
                    continue
                result = cv2.matchTemplate(frame, cv2.resize(logo_gray, (tw, th)), cv2.TM_CCOEFF_NORMED)
                _, max_val, _, max_loc = cv2.minMaxLoc(result)
                if max_val < LOGO_MATCH_NOISE:
                    continue
                x, y = max_loc
                w_frac = tw / fw
                h_frac = th / fh
                if not (LOGO_MIN_FRAC <= w_frac <= LOGO_MAX_FRAC):
                    continue
                weak_hits.append((x / fw, y / fh, w_frac, h_frac))
        if not weak_hits:
            return None
        return _densest_box(weak_hits)
    return _densest_box(hits)


def _densest_box(boxes: list[tuple[float, float, float, float]]):
    """Return the median box of a cluster of near-identical box hits.

    Templates lock onto a region; many frames agreeing on the same box is the
    strong signal. Median is robust to a few stragglers and the typical frame
    being slightly compressed/encoded.
    """
    if not boxes:
        return None
    boxes_sorted = sorted(boxes, key=lambda b: (round(b[0], 2), round(b[1], 2)))
    median_index = len(boxes_sorted) // 2
    return boxes_sorted[median_index]


def _estimate_overlay_opacity(
    frames: list[Path],
    x_frac: float,
    y_frac: float,
    w_frac: float,
    h_frac: float,
    cv2,
    np,
) -> float:
    """Estimate the mean alpha of an overlay by comparing two regions.

    For each frame we look at (a) the overlay region and (b) the same region
    in the median frame (no logo). When (a) consistently differs from (b)
    by ~K, alpha is ~1; when it's almost identical, alpha is ~0. We return
    the median normalized difference, clamped to a sensible band.
    """
    if len(frames) < 2:
        return 1.0
    if not frames:
        return 1.0
    try:
        first = cv2.imread(str(frames[0]))
    except Exception:
        return 1.0
    if first is None:
        return 1.0
    fh, fw = first.shape[:2]
    x1 = max(0, int(x_frac * fw))
    y1 = max(0, int(y_frac * fh))
    x2 = min(fw, int((x_frac + w_frac) * fw))
    y2 = min(fh, int((y_frac + h_frac) * fh))
    if x2 - x1 < 4 or y2 - y1 < 4:
        return 1.0

    region_means: list[float] = []
    diffs: list[float] = []
    median_frame_index = len(frames) // 2
    try:
        median = cv2.imread(str(frames[median_frame_index]))
        median_region = cv2.cvtColor(median[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY).astype("float32")
        median_mean = float(median_region.mean()) or 1.0
    except Exception:
        return 1.0

    for frame_path in frames:
        try:
            frame = cv2.imread(str(frame_path))
        except Exception:
            continue
        if frame is None:
            continue
        region = cv2.cvtColor(frame[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY).astype("float32")
        region_means.append(float(region.mean()))
        diffs.append(abs(float(region.mean()) - median_mean) / 255.0)
    if not diffs:
        return 1.0
    # Cap so a heavily-cut-in B-roll frame (where the overlay disappears
    # momentarily) doesn't read as 0% opacity. Reference logo is usually
    # 0.85-1.0; channel watermarks 0.4-0.7.
    return float(max(0.2, min(1.0, sorted(diffs)[len(diffs) // 2] * 6.0)))


def _detect_static_overlay(frames: list[Path], cv2, np) -> "LogoOverlay | None":
    """Find a static element that's NOT the speaker's face (no user logo).

    A logo that's the same pixels in every frame (in the same screen
    location) is a watermark. We compute a median frame and look at the
    variance of each pixel — a watermark has near-zero variance AND is far
    from the face centroid. We then expand each low-variance cluster into a
    bounding box.
    """
    if len(frames) < 4:
        return None
    try:
        loaded = []
        for frame_path in frames[:20]:
            frame = cv2.imread(str(frame_path), cv2.IMREAD_GRAYSCALE)
            if frame is None:
                continue
            height, width = frame.shape[:2]
            target_w = 360
            target_h = max(1, int(height * (target_w / max(1, width))))
            loaded.append(cv2.resize(frame, (target_w, target_h)).astype("float32"))
        if len(loaded) < 4:
            return None
        stack = np.stack(loaded, axis=0)
        median = np.median(stack, axis=0).astype("uint8")
        std = stack.std(axis=0)
    except Exception:
        return None
    fh, fw = median.shape[:2]
    edges = cv2.Canny(median, 60, 160)
    stable_edges = ((std < 7.0) & (edges > 0) & (median > 30) & (median < 245)).astype("uint8") * 255
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    mask = cv2.morphologyEx(stable_edges, cv2.MORPH_CLOSE, kernel, iterations=2)
    mask = cv2.dilate(mask, kernel, iterations=1)

    components = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if components is None:
        return None
    _, labels, stats, _ = components
    candidates: list[tuple[float, float, float, float, float]] = []
    frame_area = fw * fh
    for label in range(1, stats.shape[0]):
        x, y, w, h, area = [int(value) for value in stats[label]]
        if area <= 0:
            continue
        area_frac = area / max(1, frame_area)
        w_frac = w / max(1, fw)
        h_frac = h / max(1, fh)
        if not (0.0004 <= area_frac <= 0.045):
            continue
        if not (LOGO_MIN_FRAC <= w_frac <= LOGO_MAX_FRAC and 0.018 <= h_frac <= LOGO_MAX_FRAC):
            continue
        center_x = (x + w / 2) / fw
        center_y = (y + h / 2) / fh
        near_edge = center_x < 0.24 or center_x > 0.76 or center_y < 0.24 or center_y > 0.76
        if not near_edge:
            continue
        component_mask = labels[y : y + h, x : x + w] == label
        edge_density = float(component_mask.mean())
        if edge_density < 0.02:
            continue
        score = area_frac + edge_density * 0.01
        candidates.append((score, x / fw, y / fh, w_frac, h_frac))
    if not candidates:
        return None
    _, x_frac, y_frac, w_frac, h_frac = max(candidates, key=lambda item: item[0])
    opacity = _estimate_overlay_opacity(frames, x_frac, y_frac, w_frac, h_frac, cv2, np)
    return LogoOverlay(
        x=x_frac,
        y=y_frac,
        width=w_frac,
        height=h_frac,
        opacity=opacity,
        source_aspect=w_frac / max(0.001, h_frac),
    )
